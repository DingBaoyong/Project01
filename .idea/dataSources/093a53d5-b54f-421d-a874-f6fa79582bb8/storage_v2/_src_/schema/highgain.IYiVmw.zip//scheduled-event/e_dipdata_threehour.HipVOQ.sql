create definer = root@localhost event E_DIPDATA_THREEHOUR
  on schedule
    every '3' HOUR
      starts '2017-10-07 17:34:33'
  enable
do
  BEGIN
	    CALL P_DIPDATA_THREEHOUR();
	END;

