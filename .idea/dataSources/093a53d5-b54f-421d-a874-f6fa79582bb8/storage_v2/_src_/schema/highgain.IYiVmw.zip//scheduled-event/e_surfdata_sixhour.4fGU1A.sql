create definer = root@localhost event E_SURFDATA_SIXHOUR
  on schedule
    every '6' HOUR
      starts '2017-10-07 18:01:47'
  enable
do
  BEGIN
	    CALL P_SURFDATA_SIXHOUR();
	END;

