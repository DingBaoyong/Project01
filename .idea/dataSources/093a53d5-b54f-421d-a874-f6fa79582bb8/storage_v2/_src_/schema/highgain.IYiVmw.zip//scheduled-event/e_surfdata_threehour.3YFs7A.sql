create definer = root@localhost event E_SURFDATA_THREEHOUR
  on schedule
    every '3' HOUR
      starts '2017-10-07 18:01:12'
  enable
do
  BEGIN
	    CALL P_SURFDATA_THREEHOUR();
	END;

