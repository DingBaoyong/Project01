create definer = root@localhost event E_FLOWDATA_SIXHOUR
  on schedule
    every '6' HOUR
      starts '2017-10-07 17:41:31'
  enable
do
  BEGIN
	    CALL P_FLOWDATA_SIXHOUR();
	END;

