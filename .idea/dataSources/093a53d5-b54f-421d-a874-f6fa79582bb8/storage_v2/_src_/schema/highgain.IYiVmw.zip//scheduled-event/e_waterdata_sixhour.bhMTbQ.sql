create definer = root@localhost event E_WATERDATA_SIXHOUR
  on schedule
    every '6' HOUR
      starts '2017-10-07 18:09:26'
  enable
do
  BEGIN
	    CALL P_WATERDATA_SIXHOUR();
	END;

