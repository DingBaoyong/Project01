create definer = root@localhost event E_WATERDATA_THREEHOUR
  on schedule
    every '3' HOUR
      starts '2017-10-07 18:08:52'
  enable
do
  BEGIN
	    CALL P_WATERDATA_THREEHOUR();
	END;

