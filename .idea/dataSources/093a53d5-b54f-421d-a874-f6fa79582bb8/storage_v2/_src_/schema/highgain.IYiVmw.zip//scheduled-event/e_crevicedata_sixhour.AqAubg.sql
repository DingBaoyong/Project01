create definer = root@localhost event E_CREVICEDATA_SIXHOUR
  on schedule
    every '6' HOUR
      starts '2017-10-07 17:16:51'
  enable
do
  BEGIN
	    CALL P_CREVICEDATA_SIXHOUR();
	END;

