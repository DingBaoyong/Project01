create trigger BOOM_DEVICEEVENT_TRIG
  before INSERT
  on boom_deviceevent
  for each row
  BEGIN
	DECLARE Cur_DataId              		INT(10);	
	DECLARE CUR_DEVICEID      			INT(10);
	DECLARE CurX 					DECIMAL(10, 6); 		#当前要插入的通道X的振动幅值
        DECLARE CurY 					DECIMAL(10, 6);			#当前要插入的通道Y的振动幅值
	DECLARE CurZ 					DECIMAL(10, 6);			#当前要插入的通道Z的振动幅值
	
	DECLARE T_Alarm_Content 			VARCHAR(1000);
	DECLARE T_Alarm_Level   			INT(10);
	DECLARE T_Alarm_Name    			VARCHAR(20);
	DECLARE T_Alarm_Cnt     			INT(10) DEFAULT  0;	
	DECLARE T_Alarm_Red_Count 			INT(10) DEFAULT  0;
	DECLARE T_Alarm_Org_Count 			INT(10) DEFAULT  0;
	DECLARE T_Alarm_Yel_Count 			INT(10) DEFAULT  0;
	DECLARE Alarm_Level 				INT(10) DEFAULT  0;	
	
	
	DECLARE deviceName        			VARCHAR(20);			#报警配置相关参数
	DECLARE monitordevicecode 			INT(10);
	DECLARE projectId         			INT(10);
	DECLARE projectName       			VARCHAR(50);
	
	DECLARE alarm_X   				DECIMAL(10, 6);
	DECLARE alarm_Y   				DECIMAL(10, 6);
	DECLARE alarm_Z 				DECIMAL(10, 6);
	
	DECLARE CNT1  					INT(10) DEFAULT  0;
	DECLARE CNT2  					INT(10) DEFAULT  0;
	DECLARE CNT3  					INT(10) DEFAULT  0;
	
	DECLARE done 					INT DEFAULT FALSE;
	
	DECLARE mycur CURSOR FOR
	SELECT s.v1,	
               s.v2,
               s.v3,               
               s.ALARMTYPEID,
               (SELECT t.alarmtypename
                FROM alarmtype t
                WHERE t.id = s.alarmtypeid) alarmname
        FROM boom_alarmpara s
        WHERE s.deviceid = CUR_DEVICEID
        AND s.use_flag = 1
        ORDER BY s.ALARMTYPEID ASC;
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;				-- 指定游标循环结束时的返回值
	
	SET CUR_DEVICEID = NEW.DeviceID;
	SET CurX        = NEW.V1;
	SET CurY        = NEW.V2;
	SET CurZ        = NEW.V3;
	select t.deviceName,
	       t.monitordevicecode,
               s.projectid,
               p.projectname
	into deviceName, monitordevicecode, projectId, projectName
	from boom_device t, section s, project p
	where t.id = CUR_DEVICEID
	and t.sectionid = s.sectionid
	and s.projectid = p.projectid;
	
	SET T_Alarm_COntent =  '爆破振动';
	-- 打开游标
	OPEN mycur;
	-- 遍历游标里的数据
	read_loop:LOOP
	-- 将游标当前指向的数据，赋给当前定义的变量中
	FETCH mycur INTO alarm_X,alarm_Y,alarm_Z,T_Alarm_level,T_Alarm_Name;
	-- 判断游标的循环是否结束
	IF done THEN 
		LEAVE read_loop;			-- 跳出游标循环
	END IF;
	
	-- 通道X
	IF (CNT1 = 0 AND alarm_X <> 0 AND ABS(CurX) >= alarm_X) THEN
		SET T_Alarm_Content = CONCAT(T_Alarm_Content,'通道X振动峰值',T_Alarm_Name,',数值:',CurX,'cm/s');
		SET T_Alarm_Cnt     = T_Alarm_Cnt + 1;
		SET CNT1            = 1;
        
		IF (T_Alarm_level = 1) THEN
			SET T_Alarm_Red_Count     = T_Alarm_Red_Count + 1;
		END IF; 
		IF (T_Alarm_level = 2) THEN
			SET T_Alarm_Org_Count     = T_Alarm_Org_Count + 1;
		END IF;
		IF (T_Alarm_level = 3) THEN
			SET T_Alarm_Yel_Count     = T_Alarm_Yel_Count + 1;
		END IF;        
       END IF;
       
       IF (T_Alarm_Cnt > 0) THEN
		SET T_Alarm_COntent = CONCAT(T_Alarm_COntent,';');
		SET T_Alarm_Cnt     = 0;
       END IF;
	
       -- 通道Y
	IF (CNT2 = 0 AND alarm_Y <> 0 AND ABS(CurY) >= alarm_Y) THEN
		SET T_Alarm_Content = CONCAT(T_Alarm_Content,'通道Y振动峰值',T_Alarm_Name,',数值:',CurY,'cm/s');
		SET T_Alarm_Cnt     = T_Alarm_Cnt + 1;
		SET CNT2            = 1;
        
		IF (T_Alarm_level = 1) THEN
			SET T_Alarm_Red_Count     = T_Alarm_Red_Count + 1;
		END IF; 
		IF (T_Alarm_level = 2) THEN
			SET T_Alarm_Org_Count     = T_Alarm_Org_Count + 1;
		END IF;
		IF (T_Alarm_level = 3) THEN
			SET T_Alarm_Yel_Count     = T_Alarm_Yel_Count + 1;
		END IF;        
       END IF;
       
       IF (T_Alarm_Cnt > 0) THEN
		SET T_Alarm_COntent = CONCAT(T_Alarm_COntent,';');
		SET T_Alarm_Cnt     = 0;
       END IF;
       
       -- 通道Z
	IF (CNT3 = 0 AND alarm_Z <> 0 AND ABS(CurZ) >= alarm_Z) THEN
		SET T_Alarm_Content = CONCAT(T_Alarm_Content,'通道Z振动峰值',T_Alarm_Name,',数值:',CurZ,'cm/s');
		SET T_Alarm_Cnt     = T_Alarm_Cnt + 1;
		SET CNT3            = 1;
        
		IF (T_Alarm_level = 1) THEN
			SET T_Alarm_Red_Count     = T_Alarm_Red_Count + 1;
		END IF; 
		IF (T_Alarm_level = 2) THEN
			SET T_Alarm_Org_Count     = T_Alarm_Org_Count + 1;
		END IF;
		IF (T_Alarm_level = 3) THEN
			SET T_Alarm_Yel_Count     = T_Alarm_Yel_Count + 1;
		END IF;        
       END IF;
       
       IF (T_Alarm_Cnt > 0) THEN
		SET T_Alarm_COntent = CONCAT(T_Alarm_COntent,';');
		SET T_Alarm_Cnt     = 0;
       END IF;
       
       IF (CNT1 + CNT2 + CNT3 = 3) THEN
	LEAVE read_loop;			-- 跳出游标循环	      
       END IF;
       
       -- 结束游标循环
       END LOOP;
       -- 关闭游标
       CLOSE mycur;
       
       IF (T_Alarm_Red_Count > 0) THEN
	    SET Alarm_Level = 1;
        END IF;
        IF (T_Alarm_Red_Count =0 AND T_Alarm_Org_Count >0) THEN
	    SET Alarm_Level = 2;
        END IF;
        IF (T_Alarm_Red_Count =0 AND T_Alarm_Org_Count =0 AND T_Alarm_Yel_Count >0) THEN
	     SET Alarm_Level = 3;
        END IF;
        
        IF ('爆破振动' <> T_Alarm_COntent) THEN
          INSERT INTO ALARMLOG
            (PROJECTID,
             ALARMTYPEID,
             MONITORDEVICECODE,
             MESSAGE,
             CREATE_TIME,
             DEVICEID,
             DEVICENAME)
          VALUES
            (projectId,
             Alarm_Level,
             monitordevicecode,
             T_Alarm_COntent,
             NOW(),
             CUR_DEVICEID,
             DEVICENAME);
        END IF;
	
    END;

