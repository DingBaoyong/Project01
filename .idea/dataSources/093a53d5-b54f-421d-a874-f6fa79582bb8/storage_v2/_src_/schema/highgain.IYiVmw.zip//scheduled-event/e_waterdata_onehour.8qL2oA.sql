create definer = root@localhost event E_WATERDATA_ONEHOUR
  on schedule
    every '1' HOUR
      starts '2017-10-07 18:04:58'
  enable
do
  BEGIN
	    CALL P_WATERDATA_ONEHOUR();
	END;

