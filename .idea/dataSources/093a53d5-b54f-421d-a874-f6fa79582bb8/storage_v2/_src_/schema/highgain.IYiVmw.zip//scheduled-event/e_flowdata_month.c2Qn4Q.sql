create definer = root@localhost event E_FLOWDATA_MONTH
  on schedule
    every '1' MONTH
      starts '2017-10-07 17:43:37'
  enable
do
  BEGIN
	    CALL P_FLOWDATA_MONTH();
	END;

