create trigger SURF_DEVICEDATA_ONEHOUR_TRIG
  before INSERT
  on surf_devicedata_onehour
  for each row
  BEGIN
	
	DECLARE Cur_DataId              		INT(10);
	DECLARE CUR_DEVICEID      			INT(10);
	
	DECLARE CurDX 					DECIMAL(11, 4); 		#当前要插入的位移值
        DECLARE CurDY 					DECIMAL(11, 4);
	DECLARE CurDH 					DECIMAL(11, 4);
	DECLARE CurDXY 					DECIMAL(11, 4);
	DECLARE CurDXYH 				DECIMAL(11, 4);
	DECLARE CurVX 					DECIMAL(11, 4); 		#当前要插入的速度值
	DECLARE CurVY 					DECIMAL(11, 4);
	DECLARE CurVH 					DECIMAL(11, 4);
	DECLARE CurVXY 					DECIMAL(11, 4);
	DECLARE CurVXYH 				DECIMAL(11, 4);
	DECLARE CurAX   				DECIMAL(11, 4); 		#当前要插入的加速度值
	DECLARE CurAY   				DECIMAL(11, 4);
	DECLARE CurAH   				DECIMAL(11, 4);
	DECLARE CurAXY  				DECIMAL(11, 4);
	DECLARE CurAXYH 				DECIMAL(11, 4);
	
	DECLARE HIS_FIRST_DX,HIS_SECOND_DX 		DECIMAL(11, 4); 	        #最近两条位移值
        DECLARE HIS_FIRST_DY,HIS_SECOND_DY 		DECIMAL(11, 4);
	DECLARE HIS_FIRST_DH,HIS_SECOND_DH 		DECIMAL(11, 4);
	DECLARE HIS_FIRST_DXY,HIS_SECOND_DXY 		DECIMAL(11, 4);
	DECLARE HIS_FIRST_DXYH,HIS_SECOND_DXYH 		DECIMAL(11, 4);
	DECLARE HIS_FIRST_VX,HIS_SECOND_VX 		DECIMAL(11, 4); 		#最近两条的速度值
	DECLARE HIS_FIRST_VY,HIS_SECOND_VY 		DECIMAL(11, 4);
	DECLARE HIS_FIRST_VH,HIS_SECOND_VH 		DECIMAL(11, 4);
	DECLARE HIS_FIRST_VXY,HIS_SECOND_VXY 		DECIMAL(11, 4);
	DECLARE HIS_FIRST_VXYH,HIS_SECOND_VXYH 		DECIMAL(11, 4);
	DECLARE HIS_FIRST_AX,HIS_SECOND_AX   		DECIMAL(11, 4); 		#最近两条的加速度值
	DECLARE HIS_FIRST_AY,HIS_SECOND_AY   		DECIMAL(11, 4);
	DECLARE HIS_FIRST_AH,HIS_SECOND_AH   		DECIMAL(11, 4);
	DECLARE HIS_FIRST_AXY,HIS_SECOND_AXY 		DECIMAL(11, 4);
	DECLARE HIS_FIRST_AXYH,HIS_SECOND_AXYH		DECIMAL(11, 4);
	
	DECLARE T_Alarm_Content 			VARCHAR(1000);
	DECLARE T_Alarm_Level   			INT(10);
	DECLARE T_Alarm_Name    			VARCHAR(20);
	DECLARE T_Alarm_Cnt     			INT(10) DEFAULT  0;
	
	DECLARE T_Alarm_Red_Count 			INT(10) DEFAULT  0;
	DECLARE T_Alarm_Org_Count 			INT(10) DEFAULT  0;
	DECLARE T_Alarm_Yel_Count 			INT(10) DEFAULT  0;	
	DECLARE Alarm_Level 				INT(10) DEFAULT  0;			
	DECLARE deviceName        			VARCHAR(20);			#报警配置相关参数
	DECLARE monitordevicecode 			INT(10);
	DECLARE projectId         			INT(10);
	DECLARE projectName       			VARCHAR(50);
	DECLARE alarm_DX   				DECIMAL(11, 4);
	DECLARE alarm_DY   				DECIMAL(11, 4);
	DECLARE alarm_DH  				DECIMAL(11, 4);
	DECLARE alarm_DXY  				DECIMAL(11, 4);
	DECLARE alarm_DXYH 				DECIMAL(11, 4);
	DECLARE alarm_VX   				DECIMAL(11, 4);
	DECLARE alarm_VY   				DECIMAL(11, 4);
	DECLARE alarm_VH   				DECIMAL(11, 4);
	DECLARE alarm_VXY  				DECIMAL(11, 4);
	DECLARE alarm_VXYH 				DECIMAL(11, 4);
	DECLARE alarm_AX   				DECIMAL(11, 4);
	DECLARE alarm_AY   				DECIMAL(11, 4);
	DECLARE alarm_AH   				DECIMAL(11, 4);
	DECLARE alarm_AXY  				DECIMAL(11, 4);
	DECLARE alarm_AXYH 				DECIMAL(11, 4);
	
	DECLARE CNT1  					INT(10) DEFAULT  0;
	DECLARE CNT2  					INT(10) DEFAULT  0;
	DECLARE CNT3  					INT(10) DEFAULT  0;
	DECLARE CNT4  					INT(10) DEFAULT  0;
	DECLARE CNT5  					INT(10) DEFAULT  0;
	DECLARE CNT6  					INT(10) DEFAULT  0;
	DECLARE CNT7  					INT(10) DEFAULT  0;
	DECLARE CNT8  					INT(10) DEFAULT  0;
	DECLARE CNT9  					INT(10) DEFAULT  0;
	DECLARE CNT10 					INT(10) DEFAULT  0;
	DECLARE CNT11 					INT(10) DEFAULT  0;
	DECLARE CNT12 					INT(10) DEFAULT  0;
	DECLARE CNT13 					INT(10) DEFAULT  0;
	DECLARE CNT14 					INT(10) DEFAULT  0;
	DECLARE CNT15 					INT(10) DEFAULT  0;
	
	DECLARE count_temp				INT(10);                	#存放临时表中记录数量
	DECLARE done 					INT DEFAULT FALSE;
	DECLARE mycur CURSOR FOR
	SELECT s.dx,
               s.dy,
               s.dh,
               s.dxy,
               s.dxyh,
               s.vx,
               s.vy,
               s.vh,
               s.vxy,
               s.vxyh,
               s.ax,
               s.ay,
               s.ah,
               s.axy,
               s.axyh,
               s.ALARMTYPEID,
               (SELECT t.alarmtypename
                FROM alarmtype t
                WHERE t.id = s.alarmtypeid) alarmname
        FROM surf_alarmpara s
        WHERE s.deviceid = CUR_DEVICEID
        AND s.use_flag = 1
        ORDER BY s.ALARMTYPEID ASC;        
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;				-- 指定游标循环结束时的返回值
        
        CREATE TEMPORARY TABLE IF NOT EXISTS t_surf_devicedata_onehour_temp 			# 不存在则创建临时表
	     (
	      DATAID INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	      DEVICEID INT(10),
	      DACTIME DATETIME,
	      DX DECIMAL(11, 4),
	      DY DECIMAL(11, 4),
	      DH DECIMAL(11, 4),
	      DXY DECIMAL(11, 4),
	      DXYH DECIMAL(11, 4),
	      VX DECIMAL(11, 4),
	      VY DECIMAL(11, 4),
	      VH DECIMAL(11, 4),
	      VXY DECIMAL(11, 4),
	      VXYH DECIMAL(11, 4),
	      AX DECIMAL(11, 4),
	      AY DECIMAL(11, 4),
	      AH DECIMAL(11, 4),
	      AXY DECIMAL(11, 4),
	      AXYH DECIMAL(11, 4)
	     )ENGINE=memory DEFAULT CHARSET=utf8;	 
	 
	SELECT AUTO_INCREMENT INTO Cur_DataId FROM information_schema.`TABLES` WHERE TABLE_SCHEMA='highgain' AND TABLE_NAME='surf_devicedata_onehour';
	SET CUR_DEVICEID = NEW.DeviceID;
	SET CurDX        = NEW.DX;
	SET CurDY        = NEW.DY;
	SET CurDH        = NEW.DH;
	SET CurDXY       = NEW.DXY;
	SET CurDXYH      = NEW.DXYH;
	SET CurVX        = NEW.VX;
	SET CurVY        = NEW.VY;
	SET CurVH        = NEW.VH;
	SET CurVXY       = NEW.VXY;
	SET CurVXYH      = NEW.VXYH;
	SET CurAX        = NEW.AX;
	SET CurAY        = NEW.AY;
	SET CurAH        = NEW.AH;
	SET CurAXY       = NEW.AXY;
	SET CurAXYH      = NEW.AXYH;
	SELECT t.deviceName,
	       t.monitordevicecode,
               s.projectid,
               p.projectname
	INTO deviceName, monitordevicecode, projectId, projectName
	FROM surf_device t, section s, project p
	WHERE t.id = CUR_DEVICEID
	  AND t.sectionid = s.sectionid
	  AND s.projectid = p.projectid;	
	
	DELETE FROM t_surf_devicedata_onehour_temp;                                             -- 使用前先清空临时表 
        INSERT INTO t_surf_devicedata_onehour_temp(                                             #向临时表中插入数据
		 SELECT m.dataid,
			m.deviceId,
			m.dactime,
			m.dx,
			m.dy,
			m.dh,
			m.dxy,
			m.dxyh,
			m.vx,
			m.vy,
			m.vh,
			m.vxy,
			m.vxyh,
			m.ax,
			m.ay,
			m.ah,
			m.axy,
			m.axyh
		 FROM (SELECT t.dataid,t.deviceId,t.dactime,t.dx,t.dy,t.dh,t.dxy,t.dxyh,t.vx,t.vy,t.vh,t.vxy,t.vxyh,t.ax,t.ay,t.ah,t.axy,t.axyh
		       FROM surf_devicedata_onehour t
		       WHERE t.DATAID < Cur_DataId
		       AND t.DeviceID = CUR_DEVICEID
		       ORDER BY t.DATAID DESC LIMIT 2)m);		       
        SELECT COUNT(*) INTO count_temp FROM t_surf_devicedata_onehour_temp ;
        
        IF (count_temp = 2) THEN
	    SELECT dx,dy,dh,dxy,dxyh,vx,vy,vh,vxy,vxyh,ax,ay,ah,axy,axyh 
	      INTO HIS_FIRST_DX,HIS_FIRST_DY,HIS_FIRST_DH,HIS_FIRST_DXY,HIS_FIRST_DXYH,
		   HIS_FIRST_VX,HIS_FIRST_VY,HIS_FIRST_VH,HIS_FIRST_VXY,HIS_FIRST_VXYH,
		   HIS_FIRST_AX,HIS_FIRST_AY,HIS_FIRST_AH,HIS_FIRST_AXY,HIS_FIRST_AXYH
	      FROM t_surf_devicedata_onehour_temp LIMIT 0,1;
		 
	      SELECT dx,dy,dh,dxy,dxyh,vx,vy,vh,vxy,vxyh,ax,ay,ah,axy,axyh 
		INTO HIS_SECOND_DX,HIS_SECOND_DY,HIS_SECOND_DH,HIS_SECOND_DXY,HIS_SECOND_DXYH,
		     HIS_SECOND_VX,HIS_SECOND_VY,HIS_SECOND_VH,HIS_SECOND_VXY,HIS_SECOND_VXYH,
		     HIS_SECOND_AX,HIS_SECOND_AY,HIS_SECOND_AH,HIS_SECOND_AXY,HIS_SECOND_AXYH
		FROM t_surf_devicedata_onehour_temp LIMIT 1,1;
		       
	    -- 打开游标
	    OPEN mycur;
	    -- 遍历游标里的数据
            read_loop:LOOP
	    -- 将游标当前指向的数据，赋给当前定义的变量中
	    FETCH mycur INTO alarm_DX,alarm_DY,alarm_DH,alarm_DXY,alarm_DXYH,alarm_VX,alarm_VY,alarm_VH,alarm_VXY,alarm_VXYH,alarm_AX,alarm_AY,alarm_AH,alarm_AXY,alarm_AXYH,T_Alarm_level,T_Alarm_Name;
	    -- 判断游标的循环是否结束
	    IF done THEN 
		LEAVE read_loop;			-- 跳出游标循环
	    END IF;
	    
	-- 位移
	IF (CNT1 = 0 AND alarm_DX <> 0 AND ABS(CurDX) >= alarm_DX/1000 AND ABS(HIS_FIRST_DX) >= alarm_DX/1000 AND ABS(HIS_SECOND_DX) >= alarm_DX/1000) THEN
		SET T_Alarm_Content = CONCAT('表面位移','x方向位移',T_Alarm_Name,',数值:',CurDX*1000,'mm');
		SET T_Alarm_Cnt     = T_Alarm_Cnt + 1;
		SET CNT1            = 1;
        
		IF (T_Alarm_level = 1) THEN
			SET T_Alarm_Red_Count     = T_Alarm_Red_Count + 1;
		END IF; 
		IF (T_Alarm_level = 2) THEN
			SET T_Alarm_Org_Count     = T_Alarm_Org_Count + 1;
		END IF;
		IF (T_Alarm_level = 3) THEN
			SET T_Alarm_Yel_Count     = T_Alarm_Yel_Count + 1;
		END IF;        
       END IF;
       
       if (CNT2 = 0 and alarm_DY <> 0 AND abs(CurDY) >= alarm_DY/1000 AND abs(HIS_FIRST_DY) >= alarm_DY/1000 AND abs(HIS_SECOND_DY) >= alarm_DY/1000) then
		if (T_Alarm_Cnt > 0) then
			SET T_Alarm_COntent = CONCAT(T_Alarm_COntent,';');
		end if;
		SET T_Alarm_Content = CONCAT(T_Alarm_COntent,'y方向位移',T_Alarm_Name,',数值:',CurDY*1000,'mm');
		SET T_Alarm_Cnt     = T_Alarm_Cnt + 1;
		SET CNT2            = 1;
        
		if (T_Alarm_level = 1) then
			SET T_Alarm_Red_Count     = T_Alarm_Red_Count + 1;
		end if; 
		if (T_Alarm_level = 2) then
			SET T_Alarm_Org_Count     = T_Alarm_Org_Count + 1;
		end if;
		if (T_Alarm_level = 3) then
			SET T_Alarm_Yel_Count     = T_Alarm_Yel_Count + 1;
		end if;
        
       end if;
      
       if (CNT3 = 0 AND alarm_DH <> 0 AND abs(CurDH) >= alarm_DH/1000 AND abs(HIS_FIRST_DH) >= alarm_DH/1000 AND abs(HIS_SECOND_DH) >= alarm_DH/1000) then
		if (T_Alarm_Cnt > 0) then
			SET T_Alarm_COntent = CONCAT(T_Alarm_COntent,';');
		end if;
		SET T_Alarm_Content = CONCAT(T_Alarm_COntent,'h方向位移',T_Alarm_Name,',数值:',CurDH*1000,'mm');
		SET T_Alarm_Cnt     = T_Alarm_Cnt + 1;
		SET CNT3            = 1;
		
		if (T_Alarm_level = 1) then
			SET T_Alarm_Red_Count     = T_Alarm_Red_Count + 1;
		end if; 
		if (T_Alarm_level = 2) then
			SET T_Alarm_Org_Count     = T_Alarm_Org_Count + 1;
		end if;
		if (T_Alarm_level = 3) then
			SET T_Alarm_Yel_Count     = T_Alarm_Yel_Count + 1;
		end if;
        
       end if;
       
       if (CNT4 = 0 and alarm_DXY <> 0 AND abs(CurDXY) >= alarm_DXY/1000 AND abs(HIS_FIRST_DXY) >= alarm_DXY/1000 AND abs(HIS_SECOND_DXY) >= alarm_DXY/1000) then
		if (T_Alarm_Cnt > 0) then
			SET T_Alarm_COntent = CONCAT(T_Alarm_COntent,';');
		end if;
		SET T_Alarm_Content = CONCAT(T_Alarm_COntent,'水平方向位移',T_Alarm_Name,',数值:',CurDXY*1000,'mm');		
		SET T_Alarm_Cnt     = T_Alarm_Cnt + 1;
		SET CNT4            = 1;
		
		if (T_Alarm_level = 1) then
			SET T_Alarm_Red_Count     = T_Alarm_Red_Count + 1;
		end if; 
		if (T_Alarm_level = 2) then
			SET T_Alarm_Org_Count     = T_Alarm_Org_Count + 1;
		end if;
		if (T_Alarm_level = 3) then
			SET T_Alarm_Yel_Count     = T_Alarm_Yel_Count + 1;
		end if;
        
       end if;
       
       if (CNT5 = 0 and alarm_DXYH <> 0 AND abs(CurDXYH) >= alarm_DXYH/1000 AND abs(HIS_FIRST_DXYH) >= alarm_DXYH/1000 AND abs(HIS_SECOND_DXYH) >= alarm_DXYH/1000) then
		if (T_Alarm_Cnt > 0) then
			SET T_Alarm_COntent = CONCAT(T_Alarm_COntent,';');
		end if;
		SET T_Alarm_Content = CONCAT(T_Alarm_COntent,'三维方向位移',T_Alarm_Name,',数值:',CurDXYH*1000,'mm');		
		SET T_Alarm_Cnt     = T_Alarm_Cnt + 1;
		SET CNT5            = 1;
		
		if (T_Alarm_level = 1) then
			SET T_Alarm_Red_Count     = T_Alarm_Red_Count + 1;
		end if; 
		if (T_Alarm_level = 2) then
			SET T_Alarm_Org_Count     = T_Alarm_Org_Count + 1;
		end if;
		if (T_Alarm_level = 3) then
			SET T_Alarm_Yel_Count     = T_Alarm_Yel_Count + 1;
		end if;
        
       end if;
       
       if (T_Alarm_Cnt > 0) then
		SET T_Alarm_COntent = CONCAT(T_Alarm_COntent,'。');
		set T_Alarm_Cnt     = 0;
       end if;
       
       #速度
       if (CNT6 = 0 and alarm_VX <> 0 AND abs(CurVX) >= alarm_VX/1000 AND abs(HIS_FIRST_VX) >= alarm_VX/1000 AND abs(HIS_SECOND_VX) >= alarm_VX/1000) then
		SET T_Alarm_Content = CONCAT(T_Alarm_COntent,'x方向速度',T_Alarm_Name,',数值:',CurVX*1000,'mm/h');
		SET T_Alarm_Cnt     = T_Alarm_Cnt + 1;
		SET CNT6            = 1;
		
		if (T_Alarm_level = 1) then
			SET T_Alarm_Red_Count     = T_Alarm_Red_Count + 1;
		end if; 
		if (T_Alarm_level = 2) then
			SET T_Alarm_Org_Count     = T_Alarm_Org_Count + 1;
		end if;
		if (T_Alarm_level = 3) then
			SET T_Alarm_Yel_Count     = T_Alarm_Yel_Count + 1;
		end if;
        
       end if;
       
       if (CNT7 = 0 and alarm_VY <> 0 AND abs(CurVY) >= alarm_VY/1000 AND abs(HIS_FIRST_VY) >= alarm_VY/1000 AND abs(HIS_SECOND_VY) >= alarm_VY/1000) then
		if (T_Alarm_Cnt > 0) then
			SET T_Alarm_COntent = CONCAT(T_Alarm_COntent,';');
		end if;
		SET T_Alarm_Content = CONCAT(T_Alarm_COntent,'y方向速度',T_Alarm_Name,',数值:',CurVY*1000,'mm/h');
		SET T_Alarm_Cnt     = T_Alarm_Cnt + 1;
		SET CNT7            = 1;
		
		if (T_Alarm_level = 1) then
			SET T_Alarm_Red_Count     = T_Alarm_Red_Count + 1;
		end if; 
		if (T_Alarm_level = 2) then
			SET T_Alarm_Org_Count     = T_Alarm_Org_Count + 1;
		end if;
		if (T_Alarm_level = 3) then
			SET T_Alarm_Yel_Count     = T_Alarm_Yel_Count + 1;
		end if;
        
       end if;
       
       if (CNT8 = 0 and alarm_VH <> 0 AND abs(CurVH) >= alarm_VH/1000 AND abs(HIS_FIRST_VH) >= alarm_VH/1000 AND abs(HIS_SECOND_VH) >= alarm_VH/1000) then
		if (T_Alarm_Cnt > 0) then
			SET T_Alarm_COntent = CONCAT(T_Alarm_COntent,';');
		end if;
		SET T_Alarm_Content = CONCAT(T_Alarm_COntent,'h方向速度',T_Alarm_Name,',数值:',CurVH*1000,'mm/h');
		SET T_Alarm_Cnt     = T_Alarm_Cnt + 1;
		SET CNT8            = 1;
		
		if (T_Alarm_level = 1) then
			SET T_Alarm_Red_Count     = T_Alarm_Red_Count + 1;
		end if; 
		if (T_Alarm_level = 2) then
			SET T_Alarm_Org_Count     = T_Alarm_Org_Count + 1;
		end if;
		if (T_Alarm_level = 3) then
			SET T_Alarm_Yel_Count     = T_Alarm_Yel_Count + 1;
		end if;
        
       end if;
       
       if (CNT9 = 0 and alarm_VXY <> 0 AND abs(CurVXY) >= alarm_VXY/1000 AND abs(HIS_FIRST_VXY) >= alarm_VXY/1000 AND abs(HIS_SECOND_VXY) >= alarm_VXY/1000) then
		if (T_Alarm_Cnt > 0) then
			SET T_Alarm_COntent = CONCAT(T_Alarm_COntent,';');
		end if;
		SET T_Alarm_Content = CONCAT(T_Alarm_COntent,'水平方向速度',T_Alarm_Name,',数值:',CurVXY*1000,'mm/h');
		SET T_Alarm_Cnt     = T_Alarm_Cnt + 1;
		SET CNT9            = 1;
		
		if (T_Alarm_level = 1) then
			SET T_Alarm_Red_Count     = T_Alarm_Red_Count + 1;
		end if; 
		if (T_Alarm_level = 2) then
			SET T_Alarm_Org_Count     = T_Alarm_Org_Count + 1;
		end if;
		if (T_Alarm_level = 3) then
			SET T_Alarm_Yel_Count     = T_Alarm_Yel_Count + 1;
		end if;
        
      end if;
      
      if (CNT10 = 0 and alarm_VXYH <> 0 AND abs(CurVXYH) >= alarm_VXYH/1000 AND abs(HIS_FIRST_VXYH) >= alarm_VXYH/1000 AND abs(HIS_SECOND_VXYH) >= alarm_VXYH/1000) then
		if (T_Alarm_Cnt > 0) then
			SET T_Alarm_COntent = CONCAT(T_Alarm_COntent,';');
		end if;
		SET T_Alarm_Content = CONCAT(T_Alarm_COntent,'三维方向速度',T_Alarm_Name,',数值:',CurVXYH*1000,'mm/h');
		SET T_Alarm_Cnt     = T_Alarm_Cnt + 1;
		SET CNT10           = 1;
		
		if (T_Alarm_level = 1) then
			SET T_Alarm_Red_Count     = T_Alarm_Red_Count + 1;
		end if; 
		if (T_Alarm_level = 2) then
			SET T_Alarm_Org_Count     = T_Alarm_Org_Count + 1;
		end if;
		if (T_Alarm_level = 3) then
			SET T_Alarm_Yel_Count     = T_Alarm_Yel_Count + 1;
		end if;
        
      end if;
      
      if (T_Alarm_Cnt > 0) then
		SET T_Alarm_COntent = CONCAT(T_Alarm_COntent,'。');
		set T_Alarm_Cnt     = 0;
      end if;
      
      #加速度
      if (CNT11 = 0 AND alarm_AX <> 0 AND abs(CurAX) >= alarm_AX/1000 AND abs(HIS_FIRST_AX) >= alarm_AX/1000 AND abs(HIS_SECOND_AX) >= alarm_AX/1000) then
		SET T_Alarm_Content = CONCAT(T_Alarm_COntent,'x方向加速度',T_Alarm_Name,',数值:',CurAX*1000,'mm/h2');
		SET T_Alarm_Cnt     = T_Alarm_Cnt + 1;
		SET CNT11           = 1;
		
		if (T_Alarm_level = 1) then
			SET T_Alarm_Red_Count     = T_Alarm_Red_Count + 1;
		end if; 
		if (T_Alarm_level = 2) then
			SET T_Alarm_Org_Count     = T_Alarm_Org_Count + 1;
		end if;
		if (T_Alarm_level = 3) then
			SET T_Alarm_Yel_Count     = T_Alarm_Yel_Count + 1;
		end if;
        
      end if;
      
      if (CNT12 = 0 and alarm_AY <> 0 AND abs(CurAY) >= alarm_AY/1000 AND abs(HIS_FIRST_AY) >= alarm_AY/1000 AND abs(HIS_SECOND_AY) >= alarm_AY/1000) then
		if (T_Alarm_Cnt > 0) then
			SET T_Alarm_COntent = CONCAT(T_Alarm_COntent,';');
		end if;
		SET T_Alarm_Content = CONCAT(T_Alarm_COntent,'y方向加速度',T_Alarm_Name,',数值:',CurAY*1000,'mm/h2');
		SET T_Alarm_Cnt     = T_Alarm_Cnt + 1;
		SET CNT12           = 1;
		
		if (T_Alarm_level = 1) then
			SET T_Alarm_Red_Count     = T_Alarm_Red_Count + 1;
		end if; 
		if (T_Alarm_level = 2) then
			SET T_Alarm_Org_Count     = T_Alarm_Org_Count + 1;
		end if;
		if (T_Alarm_level = 3) then
			SET T_Alarm_Yel_Count     = T_Alarm_Yel_Count + 1;
		end if;
        
      end if;
      
      if (CNT13 = 0 and alarm_AH <> 0 AND abs(CurAH) >= alarm_AH/1000 AND abs(HIS_FIRST_AH) >= alarm_AH/1000 AND abs(HIS_SECOND_AH) >= alarm_AH/1000) then
		if (T_Alarm_Cnt > 0) then
			SET T_Alarm_COntent = CONCAT(T_Alarm_COntent,';');
		end if;
		SET T_Alarm_Content = CONCAT(T_Alarm_COntent,'h方向加速度',T_Alarm_Name,',数值:',CurAH*1000,'mm/h2');
		SET T_Alarm_Cnt     = T_Alarm_Cnt + 1;
		SET CNT13           = 1;
		
		if (T_Alarm_level = 1) then
			SET T_Alarm_Red_Count     = T_Alarm_Red_Count + 1;
		end if; 
		if (T_Alarm_level = 2) then
			SET T_Alarm_Org_Count     = T_Alarm_Org_Count + 1;
		end if;
		if (T_Alarm_level = 3) then
			SET T_Alarm_Yel_Count     = T_Alarm_Yel_Count + 1;
		end if;
        
      end if;
      
      if (CNT14 = 0 and alarm_AXY <> 0 AND abs(CurAXY) >= alarm_AXY/1000 AND abs(HIS_FIRST_AXY) >= alarm_AXY/1000 AND abs(HIS_SECOND_AXY) >= alarm_AXY/1000) then
		if (T_Alarm_Cnt > 0) then
			SET T_Alarm_COntent = CONCAT(T_Alarm_COntent,';');
		end if;
		SET T_Alarm_Content = CONCAT(T_Alarm_COntent,'水平方向加速度',T_Alarm_Name,',数值:',CurAXY*1000,'mm/h2');
		SET T_Alarm_Cnt     = T_Alarm_Cnt + 1;
		SET CNT14           = 1;
		
		if (T_Alarm_level = 1) then
			SET T_Alarm_Red_Count     = T_Alarm_Red_Count + 1;
		end if; 
		if (T_Alarm_level = 2) then
			SET T_Alarm_Org_Count     = T_Alarm_Org_Count + 1;
		end if;
		if (T_Alarm_level = 3) then
			SET T_Alarm_Yel_Count     = T_Alarm_Yel_Count + 1;
		end if;
        
      end if;
      if (CNT15 = 0 and alarm_AXYH <> 0 AND abs(CurAXYH) >= alarm_AXYH/1000 AND abs(HIS_FIRST_AXYH) >= alarm_AXYH/1000 AND abs(HIS_FIRST_AXYH) >= alarm_AXYH/1000) then
		if (T_Alarm_Cnt > 0) then
			SET T_Alarm_COntent = CONCAT(T_Alarm_COntent,';');
		end if;
		SET T_Alarm_Content = CONCAT(T_Alarm_COntent,'三维方向加速度',T_Alarm_Name,',数值:',CurAXYH*1000,'mm/h2');
		SET T_Alarm_Cnt     = T_Alarm_Cnt + 1;
		SET CNT15           = 1;
		
		if (T_Alarm_level = 1) then
			SET T_Alarm_Red_Count     = T_Alarm_Red_Count + 1;
		end if; 
		if (T_Alarm_level = 2) then
			SET T_Alarm_Org_Count     = T_Alarm_Org_Count + 1;
		end if;
		if (T_Alarm_level = 3) then
			SET T_Alarm_Yel_Count     = T_Alarm_Yel_Count + 1;
		end if;
        
      end if;
      if (T_Alarm_Cnt > 0) then
		SET T_Alarm_COntent = CONCAT(T_Alarm_COntent,'。');
		SET T_Alarm_Cnt     = 0;
      end if;
      
      IF (CNT1 + CNT2 + CNT3 + CNT4 + CNT5 + CNT6 + CNT7 + CNT8 + CNT9 +
         CNT10 + CNT11 + CNT12 + CNT13 + CNT14 + CNT15 = 15) THEN
        LEAVE read_loop;			-- 跳出游标循环	      
      END IF;
        
            -- 结束游标循环
	    END LOOP;
	    -- 关闭游标
	    CLOSE mycur;
        END IF;
        
        if (T_Alarm_Red_Count > 0) then
	    SET Alarm_Level = 1;
        end if;
        if (T_Alarm_Red_Count =0 and T_Alarm_Org_Count >0) then
	    SET Alarm_Level = 2;
        end if;
        if (T_Alarm_Red_Count =0 and T_Alarm_Org_Count =0 and T_Alarm_Yel_Count >0) then
	     SET Alarm_Level = 3;
        end if;
        
        if ('表面位移' <> T_Alarm_COntent) then
          insert into ALARMLOG
            (PROJECTID,
             ALARMTYPEID,
             MONITORDEVICECODE,
             MESSAGE,
             CREATE_TIME,
             DEVICEID,
             DEVICENAME)
          values
            (projectId,
             Alarm_Level,
             monitordevicecode,
             T_Alarm_COntent,
             NOW(),
             CUR_DEVICEID,
             DEVICENAME);
        end if;
    
    END;

