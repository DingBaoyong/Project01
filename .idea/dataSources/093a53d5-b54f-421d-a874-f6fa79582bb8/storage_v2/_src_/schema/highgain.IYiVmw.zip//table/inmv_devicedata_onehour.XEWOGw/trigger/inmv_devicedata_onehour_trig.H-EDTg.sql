create trigger INMV_DEVICEDATA_ONEHOUR_TRIG
  before INSERT
  on inmv_devicedata_onehour
  for each row
  BEGIN
    
	DECLARE Cur_DataId              		INT(10);
	DECLARE CUR_DEVICEID      			INT(10);
	
	DECLARE CurDX 					DECIMAL(11, 4); 		#当前要插入的位移值
        DECLARE CurDY 					DECIMAL(11, 4);
	DECLARE CurDH 					DECIMAL(11, 4);
	DECLARE CurDXY 					DECIMAL(11, 4);
	DECLARE CurDXYH 				DECIMAL(11, 4);
	DECLARE CurVX 					DECIMAL(11, 4); 		#当前要插入的速度值
	DECLARE CurVY 					DECIMAL(11, 4);
	DECLARE CurVH 					DECIMAL(11, 4);
	DECLARE CurVXY 					DECIMAL(11, 4);
	DECLARE CurVXYH 				DECIMAL(11, 4);
	DECLARE CurAX   				DECIMAL(11, 4); 		#当前要插入的加速度值
	DECLARE CurAY   				DECIMAL(11, 4);
	DECLARE CurAH   				DECIMAL(11, 4);
	DECLARE CurAXY  				DECIMAL(11, 4);
	DECLARE CurAXYH 				DECIMAL(11, 4);
	
	DECLARE HIS_FIRST_DX,HIS_SECOND_DX 		DECIMAL(11, 4); 	        #最近两条位移值
        DECLARE HIS_FIRST_DY,HIS_SECOND_DY 		DECIMAL(11, 4);
	DECLARE HIS_FIRST_DH,HIS_SECOND_DH 		DECIMAL(11, 4);
	DECLARE HIS_FIRST_DXY,HIS_SECOND_DXY 		DECIMAL(11, 4);
	DECLARE HIS_FIRST_DXYH,HIS_SECOND_DXYH 		DECIMAL(11, 4);
	DECLARE HIS_FIRST_VX,HIS_SECOND_VX 		DECIMAL(11, 4); 		#最近两条的速度值
	DECLARE HIS_FIRST_VY,HIS_SECOND_VY 		DECIMAL(11, 4);
	DECLARE HIS_FIRST_VH,HIS_SECOND_VH 		DECIMAL(11, 4);
	DECLARE HIS_FIRST_VXY,HIS_SECOND_VXY 		DECIMAL(11, 4);
	DECLARE HIS_FIRST_VXYH,HIS_SECOND_VXYH 		DECIMAL(11, 4);
	DECLARE HIS_FIRST_AX,HIS_SECOND_AX   		DECIMAL(11, 4); 		#最近两条的加速度值
	DECLARE HIS_FIRST_AY,HIS_SECOND_AY   		DECIMAL(11, 4);
	DECLARE HIS_FIRST_AH,HIS_SECOND_AH   		DECIMAL(11, 4);
	DECLARE HIS_FIRST_AXY,HIS_SECOND_AXY 		DECIMAL(11, 4);
	DECLARE HIS_FIRST_AXYH,HIS_SECOND_AXYH		DECIMAL(11, 4);
	
	DECLARE T_Alarm_Content 			VARCHAR(1000);
	DECLARE T_Alarm_Level   			INT(10);
	DECLARE T_Alarm_Name    			VARCHAR(20);
	DECLARE T_Alarm_Cnt     			INT(10) DEFAULT  0;
	
	DECLARE T_Alarm_Red_Count 			INT(10) DEFAULT  0;
	DECLARE T_Alarm_Org_Count 			INT(10) DEFAULT  0;
	DECLARE T_Alarm_Yel_Count 			INT(10) DEFAULT  0;	
	DECLARE Alarm_Level 				INT(10) DEFAULT  0;			
	declare innerDeviceName   			varchar(20);	
	DECLARE mainDeviceName        			VARCHAR(20);			#报警配置相关参数
	DECLARE monitordevicecode 			INT(10);
	DECLARE projectId         			INT(10);
	DECLARE projectName       			VARCHAR(50);
	DECLARE alarm_DX   				DECIMAL(11, 4);
	DECLARE alarm_DY   				DECIMAL(11, 4);
	DECLARE alarm_DH  				DECIMAL(11, 4);
	DECLARE alarm_DXY  				DECIMAL(11, 4);
	DECLARE alarm_DXYH 				DECIMAL(11, 4);
	DECLARE alarm_VX   				DECIMAL(11, 4);
	DECLARE alarm_VY   				DECIMAL(11, 4);
	DECLARE alarm_VH   				DECIMAL(11, 4);
	DECLARE alarm_VXY  				DECIMAL(11, 4);
	DECLARE alarm_VXYH 				DECIMAL(11, 4);
	DECLARE alarm_AX   				DECIMAL(11, 4);
	DECLARE alarm_AY   				DECIMAL(11, 4);
	DECLARE alarm_AH   				DECIMAL(11, 4);
	DECLARE alarm_AXY  				DECIMAL(11, 4);
	DECLARE alarm_AXYH 				DECIMAL(11, 4);
	
	DECLARE CNT1  					INT(10) DEFAULT  0;
	DECLARE CNT2  					INT(10) DEFAULT  0;
	DECLARE CNT3  					INT(10) DEFAULT  0;
	DECLARE CNT4  					INT(10) DEFAULT  0;
	DECLARE CNT5  					INT(10) DEFAULT  0;
	DECLARE CNT6  					INT(10) DEFAULT  0;
	DECLARE CNT7  					INT(10) DEFAULT  0;
	DECLARE CNT8  					INT(10) DEFAULT  0;
	DECLARE CNT9  					INT(10) DEFAULT  0;
	DECLARE CNT10 					INT(10) DEFAULT  0;
	DECLARE CNT11 					INT(10) DEFAULT  0;
	DECLARE CNT12 					INT(10) DEFAULT  0;
	DECLARE CNT13 					INT(10) DEFAULT  0;
	DECLARE CNT14 					INT(10) DEFAULT  0;
	DECLARE CNT15 					INT(10) DEFAULT  0;
	
	DECLARE count_temp				INT(10);                	#存放临时表中记录数量
	DECLARE done 					INT DEFAULT FALSE;
	DECLARE mycur CURSOR FOR
	SELECT s.dx,
               s.dy,
               s.dh,
               s.dxy,
               s.dxyh,
               s.vx,
               s.vy,
               s.vh,
               s.vxy,
               s.vxyh,
               s.ax,
               s.ay,
               s.ah,
               s.axy,
               s.axyh,
               s.ALARMTYPEID,
               (SELECT t.alarmtypename
                FROM alarmtype t
                WHERE t.id = s.alarmtypeid) alarmname
        FROM inmv_alarmpara s
        WHERE s.deviceid = CUR_DEVICEID
        AND s.use_flag = 1
        ORDER BY s.ALARMTYPEID ASC;        
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;				-- 指定游标循环结束时的返回值
        
        CREATE TEMPORARY TABLE IF NOT EXISTS t_inmv_devicedata_onehour_temp 			# 不存在则创建临时表
	     (
	      DATAID INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	      DEVICEID INT(10),
	      DACTIME DATETIME,
	      DX DECIMAL(11, 4),
	      DY DECIMAL(11, 4),
	      DH DECIMAL(11, 4),
	      DXY DECIMAL(11, 4),
	      DXYH DECIMAL(11, 4),
	      VX DECIMAL(11, 4),
	      VY DECIMAL(11, 4),
	      VH DECIMAL(11, 4),
	      VXY DECIMAL(11, 4),
	      VXYH DECIMAL(11, 4),
	      AX DECIMAL(11, 4),
	      AY DECIMAL(11, 4),
	      AH DECIMAL(11, 4),
	      AXY DECIMAL(11, 4),
	      AXYH DECIMAL(11, 4)
	     )ENGINE=memory DEFAULT CHARSET=utf8;	 
	 
	SELECT AUTO_INCREMENT INTO Cur_DataId FROM information_schema.`TABLES` WHERE TABLE_SCHEMA='highgain' AND TABLE_NAME='inmv_devicedata_onehour';
	SET CUR_DEVICEID = NEW.DeviceID;
	SET CurDX        = NEW.DX;
	SET CurDY        = NEW.DY;
	SET CurDH        = NEW.DH;
	SET CurDXY       = NEW.DXY;
	SET CurDXYH      = NEW.DXYH;
	SET CurVX        = NEW.VX;
	SET CurVY        = NEW.VY;
	SET CurVH        = NEW.VH;
	SET CurVXY       = NEW.VXY;
	SET CurVXYH      = NEW.VXYH;
	SET CurAX        = NEW.AX;
	SET CurAY        = NEW.AY;
	SET CurAH        = NEW.AH;
	SET CurAXY       = NEW.AXY;
	SET CurAXYH      = NEW.AXYH;
	select t.innerDeviceName,
	       m.monitordevicecode,
	       m.deviceName,
	       s.projectid,
	       p.projectname
	 into  innerDeviceName,monitordevicecode,mainDeviceName,projectId,projectName
	 from  inmv_device t,inmv_maindevice m,section s, project p
	 where t.id = CUR_DEVICEID
	   and t.maindeviceid = m.id
	   and m.sectionid = s.sectionid
	   and s.projectid = p.projectid;
	
	DELETE FROM t_inmv_devicedata_onehour_temp;                                             -- 使用前先清空临时表 
        INSERT INTO t_inmv_devicedata_onehour_temp(                                             #向临时表中插入数据
		 SELECT m.dataid,
			m.deviceId,
			m.dactime,
			m.dx,
			m.dy,
			m.dh,
			m.dxy,
			m.dxyh,
			m.vx,
			m.vy,
			m.vh,
			m.vxy,
			m.vxyh,
			m.ax,
			m.ay,
			m.ah,
			m.axy,
			m.axyh
		 FROM (SELECT t.dataid,t.deviceId,t.dactime,t.dx,t.dy,t.dh,t.dxy,t.dxyh,t.vx,t.vy,t.vh,t.vxy,t.vxyh,t.ax,t.ay,t.ah,t.axy,t.axyh
		       FROM inmv_devicedata_onehour t
		       WHERE t.DATAID < Cur_DataId
		       AND t.DeviceID = CUR_DEVICEID
		       ORDER BY t.DATAID DESC LIMIT 2)m);		       
        SELECT COUNT(*) INTO count_temp FROM t_inmv_devicedata_onehour_temp ;
        
        IF (count_temp = 2) THEN
	    SELECT dx,dy,dh,dxy,dxyh,vx,vy,vh,vxy,vxyh,ax,ay,ah,axy,axyh 
	      INTO HIS_FIRST_DX,HIS_FIRST_DY,HIS_FIRST_DH,HIS_FIRST_DXY,HIS_FIRST_DXYH,
		   HIS_FIRST_VX,HIS_FIRST_VY,HIS_FIRST_VH,HIS_FIRST_VXY,HIS_FIRST_VXYH,
		   HIS_FIRST_AX,HIS_FIRST_AY,HIS_FIRST_AH,HIS_FIRST_AXY,HIS_FIRST_AXYH
	      FROM t_inmv_devicedata_onehour_temp LIMIT 0,1;
		 
	      SELECT dx,dy,dh,dxy,dxyh,vx,vy,vh,vxy,vxyh,ax,ay,ah,axy,axyh 
		INTO HIS_SECOND_DX,HIS_SECOND_DY,HIS_SECOND_DH,HIS_SECOND_DXY,HIS_SECOND_DXYH,
		     HIS_SECOND_VX,HIS_SECOND_VY,HIS_SECOND_VH,HIS_SECOND_VXY,HIS_SECOND_VXYH,
		     HIS_SECOND_AX,HIS_SECOND_AY,HIS_SECOND_AH,HIS_SECOND_AXY,HIS_SECOND_AXYH
		FROM t_inmv_devicedata_onehour_temp LIMIT 1,1;
		       
	    -- 打开游标
	    OPEN mycur;
	    -- 遍历游标里的数据
            read_loop:LOOP
	    -- 将游标当前指向的数据，赋给当前定义的变量中
	    FETCH mycur INTO alarm_DX,alarm_DY,alarm_DH,alarm_DXY,alarm_DXYH,alarm_VX,alarm_VY,alarm_VH,alarm_VXY,alarm_VXYH,alarm_AX,alarm_AY,alarm_AH,alarm_AXY,alarm_AXYH,T_Alarm_level,T_Alarm_Name;
	    -- 判断游标的循环是否结束
	    IF done THEN 
		LEAVE read_loop;			-- 跳出游标循环
	    END IF;
	    
	-- 位移
	IF (CNT1 = 0 AND alarm_DX <> 0 AND ABS(CurDX) >= alarm_DX/1000 AND ABS(HIS_FIRST_DX) >= alarm_DX/1000 AND ABS(HIS_SECOND_DX) >= alarm_DX/1000) THEN
		SET T_Alarm_Content = CONCAT('内部位移','x方向位移',T_Alarm_Name,',数值:',CurDX*1000,'mm');
		SET T_Alarm_Cnt     = T_Alarm_Cnt + 1;
		SET CNT1            = 1;
        
		IF (T_Alarm_level = 1) THEN
			SET T_Alarm_Red_Count     = T_Alarm_Red_Count + 1;
		END IF; 
		IF (T_Alarm_level = 2) THEN
			SET T_Alarm_Org_Count     = T_Alarm_Org_Count + 1;
		END IF;
		IF (T_Alarm_level = 3) THEN
			SET T_Alarm_Yel_Count     = T_Alarm_Yel_Count + 1;
		END IF;        
       END IF;
       
       IF (CNT2 = 0 AND alarm_DY <> 0 AND ABS(CurDY) >= alarm_DY/1000 AND ABS(HIS_FIRST_DY) >= alarm_DY/1000 AND ABS(HIS_SECOND_DY) >= alarm_DY/1000) THEN
		IF (T_Alarm_Cnt > 0) THEN
			SET T_Alarm_COntent = CONCAT(T_Alarm_COntent,';');
		END IF;
		SET T_Alarm_Content = CONCAT(T_Alarm_COntent,'y方向位移',T_Alarm_Name,',数值:',CurDY*1000,'mm');
		SET T_Alarm_Cnt     = T_Alarm_Cnt + 1;
		SET CNT2            = 1;
        
		IF (T_Alarm_level = 1) THEN
			SET T_Alarm_Red_Count     = T_Alarm_Red_Count + 1;
		END IF; 
		IF (T_Alarm_level = 2) THEN
			SET T_Alarm_Org_Count     = T_Alarm_Org_Count + 1;
		END IF;
		IF (T_Alarm_level = 3) THEN
			SET T_Alarm_Yel_Count     = T_Alarm_Yel_Count + 1;
		END IF;
        
       END IF;
      
       IF (CNT3 = 0 AND alarm_DH <> 0 AND ABS(CurDH) >= alarm_DH/1000 AND ABS(HIS_FIRST_DH) >= alarm_DH/1000 AND ABS(HIS_SECOND_DH) >= alarm_DH/1000) THEN
		IF (T_Alarm_Cnt > 0) THEN
			SET T_Alarm_COntent = CONCAT(T_Alarm_COntent,';');
		END IF;
		SET T_Alarm_Content = CONCAT(T_Alarm_COntent,'h方向位移',T_Alarm_Name,',数值:',CurDH*1000,'mm');
		SET T_Alarm_Cnt     = T_Alarm_Cnt + 1;
		SET CNT3            = 1;
		
		IF (T_Alarm_level = 1) THEN
			SET T_Alarm_Red_Count     = T_Alarm_Red_Count + 1;
		END IF; 
		IF (T_Alarm_level = 2) THEN
			SET T_Alarm_Org_Count     = T_Alarm_Org_Count + 1;
		END IF;
		IF (T_Alarm_level = 3) THEN
			SET T_Alarm_Yel_Count     = T_Alarm_Yel_Count + 1;
		END IF;
        
       END IF;
       
       IF (CNT4 = 0 AND alarm_DXY <> 0 AND ABS(CurDXY) >= alarm_DXY/1000 AND ABS(HIS_FIRST_DXY) >= alarm_DXY/1000 AND ABS(HIS_SECOND_DXY) >= alarm_DXY/1000) THEN
		IF (T_Alarm_Cnt > 0) THEN
			SET T_Alarm_COntent = CONCAT(T_Alarm_COntent,';');
		END IF;
		SET T_Alarm_Content = CONCAT(T_Alarm_COntent,'水平方向位移',T_Alarm_Name,',数值:',CurDXY*1000,'mm');		
		SET T_Alarm_Cnt     = T_Alarm_Cnt + 1;
		SET CNT4            = 1;
		
		IF (T_Alarm_level = 1) THEN
			SET T_Alarm_Red_Count     = T_Alarm_Red_Count + 1;
		END IF; 
		IF (T_Alarm_level = 2) THEN
			SET T_Alarm_Org_Count     = T_Alarm_Org_Count + 1;
		END IF;
		IF (T_Alarm_level = 3) THEN
			SET T_Alarm_Yel_Count     = T_Alarm_Yel_Count + 1;
		END IF;
        
       END IF;
       
       IF (CNT5 = 0 AND alarm_DXYH <> 0 AND ABS(CurDXYH) >= alarm_DXYH/1000 AND ABS(HIS_FIRST_DXYH) >= alarm_DXYH/1000 AND ABS(HIS_SECOND_DXYH) >= alarm_DXYH/1000) THEN
		IF (T_Alarm_Cnt > 0) THEN
			SET T_Alarm_COntent = CONCAT(T_Alarm_COntent,';');
		END IF;
		SET T_Alarm_Content = CONCAT(T_Alarm_COntent,'三维方向位移',T_Alarm_Name,',数值:',CurDXYH*1000,'mm');		
		SET T_Alarm_Cnt     = T_Alarm_Cnt + 1;
		SET CNT5            = 1;
		
		IF (T_Alarm_level = 1) THEN
			SET T_Alarm_Red_Count     = T_Alarm_Red_Count + 1;
		END IF; 
		IF (T_Alarm_level = 2) THEN
			SET T_Alarm_Org_Count     = T_Alarm_Org_Count + 1;
		END IF;
		IF (T_Alarm_level = 3) THEN
			SET T_Alarm_Yel_Count     = T_Alarm_Yel_Count + 1;
		END IF;
        
       END IF;
       
       IF (T_Alarm_Cnt > 0) THEN
		SET T_Alarm_COntent = CONCAT(T_Alarm_COntent,'。');
		SET T_Alarm_Cnt     = 0;
       END IF;
       
       #速度
       IF (CNT6 = 0 AND alarm_VX <> 0 AND ABS(CurVX) >= alarm_VX/1000 AND ABS(HIS_FIRST_VX) >= alarm_VX/1000 AND ABS(HIS_SECOND_VX) >= alarm_VX/1000) THEN
		SET T_Alarm_Content = CONCAT(T_Alarm_COntent,'x方向速度',T_Alarm_Name,',数值:',CurVX*1000,'mm/h');
		SET T_Alarm_Cnt     = T_Alarm_Cnt + 1;
		SET CNT6            = 1;
		
		IF (T_Alarm_level = 1) THEN
			SET T_Alarm_Red_Count     = T_Alarm_Red_Count + 1;
		END IF; 
		IF (T_Alarm_level = 2) THEN
			SET T_Alarm_Org_Count     = T_Alarm_Org_Count + 1;
		END IF;
		IF (T_Alarm_level = 3) THEN
			SET T_Alarm_Yel_Count     = T_Alarm_Yel_Count + 1;
		END IF;
        
       END IF;
       
       IF (CNT7 = 0 AND alarm_VY <> 0 AND ABS(CurVY) >= alarm_VY/1000 AND ABS(HIS_FIRST_VY) >= alarm_VY/1000 AND ABS(HIS_SECOND_VY) >= alarm_VY/1000) THEN
		IF (T_Alarm_Cnt > 0) THEN
			SET T_Alarm_COntent = CONCAT(T_Alarm_COntent,';');
		END IF;
		SET T_Alarm_Content = CONCAT(T_Alarm_COntent,'y方向速度',T_Alarm_Name,',数值:',CurVY*1000,'mm/h');
		SET T_Alarm_Cnt     = T_Alarm_Cnt + 1;
		SET CNT7            = 1;
		
		IF (T_Alarm_level = 1) THEN
			SET T_Alarm_Red_Count     = T_Alarm_Red_Count + 1;
		END IF; 
		IF (T_Alarm_level = 2) THEN
			SET T_Alarm_Org_Count     = T_Alarm_Org_Count + 1;
		END IF;
		IF (T_Alarm_level = 3) THEN
			SET T_Alarm_Yel_Count     = T_Alarm_Yel_Count + 1;
		END IF;
        
       END IF;
       
       IF (CNT8 = 0 AND alarm_VH <> 0 AND ABS(CurVH) >= alarm_VH/1000 AND ABS(HIS_FIRST_VH) >= alarm_VH/1000 AND ABS(HIS_SECOND_VH) >= alarm_VH/1000) THEN
		IF (T_Alarm_Cnt > 0) THEN
			SET T_Alarm_COntent = CONCAT(T_Alarm_COntent,';');
		END IF;
		SET T_Alarm_Content = CONCAT(T_Alarm_COntent,'h方向速度',T_Alarm_Name,',数值:',CurVH*1000,'mm/h');
		SET T_Alarm_Cnt     = T_Alarm_Cnt + 1;
		SET CNT8            = 1;
		
		IF (T_Alarm_level = 1) THEN
			SET T_Alarm_Red_Count     = T_Alarm_Red_Count + 1;
		END IF; 
		IF (T_Alarm_level = 2) THEN
			SET T_Alarm_Org_Count     = T_Alarm_Org_Count + 1;
		END IF;
		IF (T_Alarm_level = 3) THEN
			SET T_Alarm_Yel_Count     = T_Alarm_Yel_Count + 1;
		END IF;
        
       END IF;
       
       IF (CNT9 = 0 AND alarm_VXY <> 0 AND ABS(CurVXY) >= alarm_VXY/1000 AND ABS(HIS_FIRST_VXY) >= alarm_VXY/1000 AND ABS(HIS_SECOND_VXY) >= alarm_VXY/1000) THEN
		IF (T_Alarm_Cnt > 0) THEN
			SET T_Alarm_COntent = CONCAT(T_Alarm_COntent,';');
		END IF;
		SET T_Alarm_Content = CONCAT(T_Alarm_COntent,'水平方向速度',T_Alarm_Name,',数值:',CurVXY*1000,'mm/h');
		SET T_Alarm_Cnt     = T_Alarm_Cnt + 1;
		SET CNT9            = 1;
		
		IF (T_Alarm_level = 1) THEN
			SET T_Alarm_Red_Count     = T_Alarm_Red_Count + 1;
		END IF; 
		IF (T_Alarm_level = 2) THEN
			SET T_Alarm_Org_Count     = T_Alarm_Org_Count + 1;
		END IF;
		IF (T_Alarm_level = 3) THEN
			SET T_Alarm_Yel_Count     = T_Alarm_Yel_Count + 1;
		END IF;
        
      END IF;
      
      IF (CNT10 = 0 AND alarm_VXYH <> 0 AND ABS(CurVXYH) >= alarm_VXYH/1000 AND ABS(HIS_FIRST_VXYH) >= alarm_VXYH/1000 AND ABS(HIS_SECOND_VXYH) >= alarm_VXYH/1000) THEN
		IF (T_Alarm_Cnt > 0) THEN
			SET T_Alarm_COntent = CONCAT(T_Alarm_COntent,';');
		END IF;
		SET T_Alarm_Content = CONCAT(T_Alarm_COntent,'三维方向速度',T_Alarm_Name,',数值:',CurVXYH*1000,'mm/h');
		SET T_Alarm_Cnt     = T_Alarm_Cnt + 1;
		SET CNT10           = 1;
		
		IF (T_Alarm_level = 1) THEN
			SET T_Alarm_Red_Count     = T_Alarm_Red_Count + 1;
		END IF; 
		IF (T_Alarm_level = 2) THEN
			SET T_Alarm_Org_Count     = T_Alarm_Org_Count + 1;
		END IF;
		IF (T_Alarm_level = 3) THEN
			SET T_Alarm_Yel_Count     = T_Alarm_Yel_Count + 1;
		END IF;
        
      END IF;
      
      IF (T_Alarm_Cnt > 0) THEN
		SET T_Alarm_COntent = CONCAT(T_Alarm_COntent,'。');
		SET T_Alarm_Cnt     = 0;
      END IF;
      
      #加速度
      IF (CNT11 = 0 AND alarm_AX <> 0 AND ABS(CurAX) >= alarm_AX/1000 AND ABS(HIS_FIRST_AX) >= alarm_AX/1000 AND ABS(HIS_SECOND_AX) >= alarm_AX/1000) THEN
		SET T_Alarm_Content = CONCAT(T_Alarm_COntent,'x方向加速度',T_Alarm_Name,',数值:',CurAX*1000,'mm/h2');
		SET T_Alarm_Cnt     = T_Alarm_Cnt + 1;
		SET CNT11           = 1;
		
		IF (T_Alarm_level = 1) THEN
			SET T_Alarm_Red_Count     = T_Alarm_Red_Count + 1;
		END IF; 
		IF (T_Alarm_level = 2) THEN
			SET T_Alarm_Org_Count     = T_Alarm_Org_Count + 1;
		END IF;
		IF (T_Alarm_level = 3) THEN
			SET T_Alarm_Yel_Count     = T_Alarm_Yel_Count + 1;
		END IF;
        
      END IF;
      
      IF (CNT12 = 0 AND alarm_AY <> 0 AND ABS(CurAY) >= alarm_AY/1000 AND ABS(HIS_FIRST_AY) >= alarm_AY/1000 AND ABS(HIS_SECOND_AY) >= alarm_AY/1000) THEN
		IF (T_Alarm_Cnt > 0) THEN
			SET T_Alarm_COntent = CONCAT(T_Alarm_COntent,';');
		END IF;
		SET T_Alarm_Content = CONCAT(T_Alarm_COntent,'y方向加速度',T_Alarm_Name,',数值:',CurAY*1000,'mm/h2');
		SET T_Alarm_Cnt     = T_Alarm_Cnt + 1;
		SET CNT12           = 1;
		
		IF (T_Alarm_level = 1) THEN
			SET T_Alarm_Red_Count     = T_Alarm_Red_Count + 1;
		END IF; 
		IF (T_Alarm_level = 2) THEN
			SET T_Alarm_Org_Count     = T_Alarm_Org_Count + 1;
		END IF;
		IF (T_Alarm_level = 3) THEN
			SET T_Alarm_Yel_Count     = T_Alarm_Yel_Count + 1;
		END IF;
        
      END IF;
      
      IF (CNT13 = 0 AND alarm_AH <> 0 AND ABS(CurAH) >= alarm_AH/1000 AND ABS(HIS_FIRST_AH) >= alarm_AH/1000 AND ABS(HIS_SECOND_AH) >= alarm_AH/1000) THEN
		IF (T_Alarm_Cnt > 0) THEN
			SET T_Alarm_COntent = CONCAT(T_Alarm_COntent,';');
		END IF;
		SET T_Alarm_Content = CONCAT(T_Alarm_COntent,'h方向加速度',T_Alarm_Name,',数值:',CurAH*1000,'mm/h2');
		SET T_Alarm_Cnt     = T_Alarm_Cnt + 1;
		SET CNT13           = 1;
		
		IF (T_Alarm_level = 1) THEN
			SET T_Alarm_Red_Count     = T_Alarm_Red_Count + 1;
		END IF; 
		IF (T_Alarm_level = 2) THEN
			SET T_Alarm_Org_Count     = T_Alarm_Org_Count + 1;
		END IF;
		IF (T_Alarm_level = 3) THEN
			SET T_Alarm_Yel_Count     = T_Alarm_Yel_Count + 1;
		END IF;
        
      END IF;
      
      IF (CNT14 = 0 AND alarm_AXY <> 0 AND ABS(CurAXY) >= alarm_AXY/1000 AND ABS(HIS_FIRST_AXY) >= alarm_AXY/1000 AND ABS(HIS_SECOND_AXY) >= alarm_AXY/1000) THEN
		IF (T_Alarm_Cnt > 0) THEN
			SET T_Alarm_COntent = CONCAT(T_Alarm_COntent,';');
		END IF;
		SET T_Alarm_Content = CONCAT(T_Alarm_COntent,'水平方向加速度',T_Alarm_Name,',数值:',CurAXY*1000,'mm/h2');
		SET T_Alarm_Cnt     = T_Alarm_Cnt + 1;
		SET CNT14           = 1;
		
		IF (T_Alarm_level = 1) THEN
			SET T_Alarm_Red_Count     = T_Alarm_Red_Count + 1;
		END IF; 
		IF (T_Alarm_level = 2) THEN
			SET T_Alarm_Org_Count     = T_Alarm_Org_Count + 1;
		END IF;
		IF (T_Alarm_level = 3) THEN
			SET T_Alarm_Yel_Count     = T_Alarm_Yel_Count + 1;
		END IF;
        
      END IF;
      IF (CNT15 = 0 AND alarm_AXYH <> 0 AND ABS(CurAXYH) >= alarm_AXYH/1000 AND ABS(HIS_FIRST_AXYH) >= alarm_AXYH/1000 AND ABS(HIS_FIRST_AXYH) >= alarm_AXYH/1000) THEN
		IF (T_Alarm_Cnt > 0) THEN
			SET T_Alarm_COntent = CONCAT(T_Alarm_COntent,';');
		END IF;
		SET T_Alarm_Content = CONCAT(T_Alarm_COntent,'三维方向加速度',T_Alarm_Name,',数值:',CurAXYH*1000,'mm/h2');
		SET T_Alarm_Cnt     = T_Alarm_Cnt + 1;
		SET CNT15           = 1;
		
		IF (T_Alarm_level = 1) THEN
			SET T_Alarm_Red_Count     = T_Alarm_Red_Count + 1;
		END IF; 
		IF (T_Alarm_level = 2) THEN
			SET T_Alarm_Org_Count     = T_Alarm_Org_Count + 1;
		END IF;
		IF (T_Alarm_level = 3) THEN
			SET T_Alarm_Yel_Count     = T_Alarm_Yel_Count + 1;
		END IF;
        
      END IF;
      IF (T_Alarm_Cnt > 0) THEN
		SET T_Alarm_COntent = CONCAT(T_Alarm_COntent,'。');
		SET T_Alarm_Cnt     = 0;
      END IF;
      
      IF (CNT1 + CNT2 + CNT3 + CNT4 + CNT5 + CNT6 + CNT7 + CNT8 + CNT9 +
         CNT10 + CNT11 + CNT12 + CNT13 + CNT14 + CNT15 = 15) THEN
        LEAVE read_loop;			-- 跳出游标循环	      
      END IF;
        
            -- 结束游标循环
	    END LOOP;
	    -- 关闭游标
	    CLOSE mycur;
        END IF;
        
        IF (T_Alarm_Red_Count > 0) THEN
	    SET Alarm_Level = 1;
        END IF;
        IF (T_Alarm_Red_Count =0 AND T_Alarm_Org_Count >0) THEN
	    SET Alarm_Level = 2;
        END IF;
        IF (T_Alarm_Red_Count =0 AND T_Alarm_Org_Count =0 AND T_Alarm_Yel_Count >0) THEN
	     SET Alarm_Level = 3;
        END IF;
        
        IF ('内部位移' <> T_Alarm_COntent) THEN
          INSERT INTO ALARMLOG
            (PROJECTID,
             ALARMTYPEID,
             MONITORDEVICECODE,
             MESSAGE,
             CREATE_TIME,
             DEVICEID,
             DEVICENAME)
          VALUES
            (projectId,
             Alarm_Level,
             monitordevicecode,
             T_Alarm_COntent,
             NOW(),
             CUR_DEVICEID,
             CONCAT(mainDeviceName,'_',innerDeviceName));
        END IF;
    
    END;

