create definer = root@localhost event E_INMVDATA_SIXHOUR
  on schedule
    every '6' HOUR
      starts '2017-10-07 17:46:25'
  enable
do
  BEGIN
	    CALL P_INMVDATA_SIXHOUR();
	END;

