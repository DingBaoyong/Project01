create definer = root@localhost event E_DIPDATA_ONEHOUR
  on schedule
    every '1' HOUR
      starts '2017-10-07 17:33:29'
  enable
do
  BEGIN
	    CALL P_DIPDATA_ONEHOUR();
	END;

