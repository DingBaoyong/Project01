create definer = root@localhost event E_FLOWDATA_TWOHOUR
  on schedule
    every '2' HOUR
      starts '2017-10-07 17:38:19'
  enable
do
  BEGIN
	    CALL P_FLOWDATA_TWOHOUR();
	END;

