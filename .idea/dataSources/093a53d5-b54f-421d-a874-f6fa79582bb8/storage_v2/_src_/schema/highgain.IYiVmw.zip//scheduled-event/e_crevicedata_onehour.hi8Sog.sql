create definer = root@localhost event E_CREVICEDATA_ONEHOUR
  on schedule
    every '1' HOUR
      starts '2017-10-07 17:05:18'
  enable
do
  BEGIN
	    CALL P_CREVICEDATA_ONEHOUR();
	END;

