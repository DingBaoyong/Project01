create trigger INMV_DEVICEDATA_TRIG
  before INSERT
  on inmv_devicedata
  for each row
  BEGIN
    
	DECLARE CurDX,CurDY,CurDH 				DECIMAL(13, 4);		#当前要插入的数据
	DECLARE CurDataId,CurDeviceID   			INT(10);
	DECLARE CurDacTime  					DATETIME;
	DECLARE t 						DECIMAL(12, 7);
	
	DECLARE OX,OY,OH,OXY,OXYH				DECIMAL(13, 4);	
	DECLARE T_VX,T_VY,T_VH,T_VXY,T_VXYH			DECIMAL(13, 4);	
	DECLARE T_AX,T_AY,T_AH,T_AXY,T_AXYH 			DECIMAL(13, 4);	
	
	DECLARE T_DX,T_DY,T_DH					DECIMAL(13, 4);		#临时变量，用于存储中间值
	
	DECLARE projectName,mainDeviceName,innerDeviceName	VARCHAR(20);
	DECLARE projectId,monitorDeviceCode			INT(10);
	
	DECLARE count_temp			INT(10);                		#存放临时表中记录数量
	DECLARE temp_DX,temp_DY,temp_DH		DECIMAL(13, 4);
	DECLARE temp_VX,temp_VY,temp_VH		DECIMAL(13, 4);
	DECLARE temp_DacTime			DATETIME;
	
	DECLARE count_data 			INT(10)  DEFAULT 0;
	
	CREATE TEMPORARY TABLE IF NOT EXISTS t_inmv_devicedata_temp 			# 不存在则创建临时表
	     (
	      DATAID INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	      DEVICEID INT(10),
	      DACTIME DATETIME,
	      `DX` DECIMAL(13, 4),
	      `DY` DECIMAL(13, 4),
	      `DH` DECIMAL(13, 4),
	      VX DECIMAL(13, 4),
	      VY DECIMAL(13, 4),
	      VH DECIMAL(13, 4)
	     )ENGINE=memory DEFAULT CHARSET=utf8;
	 
	 SELECT AUTO_INCREMENT INTO CurDataId FROM information_schema.`TABLES` WHERE TABLE_SCHEMA='highgain' AND TABLE_NAME='inmv_devicedata';
	 SET CurDeviceID  = NEW.DeviceID;
	 SET CurDX        = NEW.DX;
	 SET CurDY        = NEW.DY;
	 SET CurDH        = NEW.DH;
	 SET CurDacTime   = NEW.DACTIME;
	 
	 select t.innerDeviceName,
                m.monitordevicecode,
		m.deviceName,
		s.projectid,
		p.projectname
	 into  innerDeviceName,monitordevicecode,mainDeviceName,projectId,projectName
	 from  inmv_device t,inmv_maindevice m,section s, project p
	 where t.id = CurDeviceID
	   and t.maindeviceid = m.id
	   and m.sectionid = s.sectionid
	   and s.projectid = p.projectid;
	   
	 DELETE FROM t_inmv_devicedata_temp; -- 使用前先清空临时表
	 
	 INSERT INTO t_inmv_devicedata_temp(
		 SELECT m.dataid,
			m.deviceId,
			m.dactime,
			m.dx,
			m.dy,
			m.dh,
			m.vx,
			m.vy,
			m.vh
		 FROM (SELECT t.dataid,t.deviceId,t.dactime,t.dx,t.dy,t.dh,t.vx,t.vy,t.vh
		       FROM Inmv_DeviceData t
		       WHERE t.DataID < CurDataId
		       AND t.DeviceID = CurDeviceID
		       ORDER BY t.dataid DESC LIMIT 2)m);
	SELECT COUNT(*) INTO count_temp FROM t_inmv_devicedata_temp ;
	
	IF (count_temp >= 1) THEN	
	    SELECT dx,dy,dh,vx,vy,vh,dactime INTO temp_DX,temp_DY,temp_DH,temp_VX,temp_VY,temp_VH,temp_DacTime FROM t_inmv_devicedata_temp ORDER BY dataid DESC LIMIT 1;
	    SET OX   = CurDX;
	    SET OY   = CurDY;
	    SET OH   = CurDH;
	    SET OXY  = SQRT(POWER(OX, 2) + POWER(OY, 2));
	    SET OXYH = SQRT(POWER(OX, 2) + POWER(OY, 2) + POWER(OH, 2));
	    
	    set T_DX = CurDX - temp_DX;
            set T_DY = CurDY - temp_DY;
	    set T_DH = CurDH - temp_DH;
	    
	    SET t = (UNIX_TIMESTAMP(CurDacTime) - UNIX_TIMESTAMP(temp_DacTime))/3600; -- hours  不可能为整数
	    
	    SET T_VX = T_DX / t; -- unit: m/hour
	    SET T_VY = T_DY / t;
	    SET T_VH = T_DH / t;
	    SET T_VXY = SQRT(POWER(T_VX, 2) + POWER(T_VY, 2));
	    SET T_VXYH = SQRT(POWER(T_VX, 2) + POWER(T_VY, 2) + POWER(T_VH, 2));
	    
	    IF (count_temp = 2) THEN
		SET T_AX   = (T_VX - temp_VX) / t;
	        SET T_AY   = (T_VY - temp_VY) / t;
	        SET T_AH   = (T_VH - temp_VH) / t;
	        SET T_AXY  = SQRT(POWER(T_AX, 2) + POWER(T_AY, 2));
	        SET T_AXYH = SQRT(POWER(T_AX, 2) + POWER(T_AY, 2) + POWER(T_AH, 2));
	    ELSE
	      SET T_AX   = 0;
	      SET T_AY   = 0;
	      SET T_AH   = 0;
	      SET T_AXY  = 0;
	      SET T_AXYH = 0;
	    END IF;
	ELSE
	    SET OX     = 0;
	    SET OY     = 0;
	    SET OH     = 0;
	    SET T_AX   = 0;
	    SET T_AY   = 0;
	    SET T_AH   = 0;
	    SET OXY    = 0;
            SET OXYH   = 0;
	    SET T_AXY  = 0;
	    SET T_AXYH = 0;
	    SET T_VX   = 0;
	    SET T_VY   = 0;
	    SET T_VH   = 0;
	    SET T_VXY  = 0;
	    SET T_VXYH = 0;
	END IF;
	
	SET NEW.DX   = OX;
	SET NEW.DY   = OY;
	SET NEW.DH   = OH;
	SET NEW.AX   = T_AX;
	SET NEW.AY   = T_AY;
	SET NEW.AH   = T_AH;
	SET NEW.DXY  = OXY;
	SET NEW.DXYH = OXYH;
	SET NEW.AXY  = T_AXY;
	SET NEW.AXYH = T_AXYH;
	SET NEW.VX   = T_VX;
	SET NEW.VY   = T_VY;
	SET NEW.VH   = T_VH;
	SET NEW.VXY  = T_VXY;
	SET NEW.VXYH = T_VXYH;
	
	/*delete t from NEWDEVICEDATA t where t.monitordevicecode=2 and t.deviceid=CurDeviceID;
	insert into NEWDEVICEDATA
	      (projectid,
	       monitordevicecode,
	       dacetime,
	       deviceid,
	       devicename,
	       maindevicename,
	       v1,
	       v2,
	       v3,
	       v4,
	       v5,
	       v6,
	       v7,
	       v8,
	       v9,
	       v10,
	       v11,
	       v12,
	       v13,
	       v14,
	       v15)
	    values
	       (projectId,
		2,
		CurDacTime,
		CurDeviceID,
		innerDeviceName,
		mainDeviceName,
		OX,
		OY,
		OH,
		OXY,
		OXYH,
		T_VX,
		T_VY,
		T_VH,
		T_VXY,
		T_VXYH,
		T_AX,
		T_AY,
		T_AH,
		T_AXY,
		T_AXYH);*/
	
	/*select count(*) into count_data from NEWDEVICEDATA where monitordevicecode=2 and deviceid=CurDeviceID;
	if (count_data = 0) then
	    insert into NEWDEVICEDATA
	      (projectid,
	       monitordevicecode,
	       dacetime,
	       deviceid,
	       devicename,
	       maindevicename,
	       v1,
	       v2,
	       v3,
	       v4,
	       v5,
	       v6,
	       v7,
	       v8,
	       v9,
	       v10,
	       v11,
	       v12,
	       v13,
	       v14,
	       v15)
	    values
	       (projectId,
		monitordevicecode,
		CurDacTime,
		CurDeviceID,
		innerDeviceName,
		mainDeviceName,
		OX,
		OY,
		OH,
		OXY,
		OXYH,
		T_VX,
		T_VY,
		T_VH,
		T_VXY,
		T_VXYH,
		T_AX,
		T_AY,
		T_AH,
		T_AXY,
		T_AXYH);
	else
	    update NEWDEVICEDATA t set t.dacetime=CurDacTime,t.devicename=innerDeviceName,t.maindevicename=mainDeviceName,t.v1=OX,t.v2=OY,t.v3=OH,t.v4=OXY,t.v5=OXYH,t.v6=T_VX,t.v7=T_VY,t.v8=T_VH,t.v9=T_VXY,t.v10=T_VXYH,t.v11=T_AX,t.v12=T_AY,t.v13=T_AH,t.v14=T_AXY,t.v15=T_AXYH
	    where t.monitordevicecode=2 and t.deviceid=CurDeviceID;
	       
	end if;*/
	
    END;

