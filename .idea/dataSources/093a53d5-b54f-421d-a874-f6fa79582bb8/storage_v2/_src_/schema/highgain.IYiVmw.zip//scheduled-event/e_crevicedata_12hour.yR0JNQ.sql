create definer = root@localhost event E_CREVICEDATA_12HOUR
  on schedule
    every '12' HOUR
      starts '2017-10-07 17:17:38'
  enable
do
  BEGIN
	    CALL P_CREVICEDATA_12HOUR();
	END;

