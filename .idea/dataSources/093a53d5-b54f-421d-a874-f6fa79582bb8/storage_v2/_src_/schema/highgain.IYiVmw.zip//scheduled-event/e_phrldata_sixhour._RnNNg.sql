create definer = root@localhost event E_PHRLDATA_SIXHOUR
  on schedule
    every '6' HOUR
      starts '2017-10-07 17:56:32'
  enable
do
  BEGIN
	    CALL P_PHRLDATA_SIXHOUR();
	END;

