create definer = root@localhost event E_WINDDATA_SIXHOUR
  on schedule
    every '6' HOUR
      starts '2017-10-07 18:15:47'
  enable
do
  BEGIN
	    CALL P_WINDDATA_SIXHOUR();
	END;

