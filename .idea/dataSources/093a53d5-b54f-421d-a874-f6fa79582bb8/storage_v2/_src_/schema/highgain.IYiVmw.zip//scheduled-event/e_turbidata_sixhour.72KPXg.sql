create definer = root@localhost event E_TURBIDATA_SIXHOUR
  on schedule
    every '6' HOUR
      starts '2017-10-07 17:28:54'
  enable
do
  BEGIN
	    CALL P_TURBIDATA_SIXHOUR();
	END;

