create trigger RAIN_DEVICEDATA_HOUR_TRIG
  before INSERT
  on rain_devicedata_hour
  for each row
  BEGIN
    
	DECLARE CUR_ID            INT(10);
	DECLARE CUR_VAL           DECIMAL(7, 2);
	DECLARE HIS_FIRST_VAL     DECIMAL(7, 2);
        DECLARE HIS_SECOND_VAL    DECIMAL(7, 2);	
	DECLARE ALARM_VAL         DECIMAL(7, 2);
	DECLARE CUR_DEVICEID      INT(10);
	DECLARE DEVICENAME        VARCHAR(20);
	DECLARE MONITORDEVICECODE INT(10);
	DECLARE PROJECTID         INT(10);
	DECLARE ALARMTYPEID       INT(10);
	DECLARE ALARMTYPENAME     VARCHAR(20);
	DECLARE ALARM_MESSAGE     VARCHAR(200);
	
	DECLARE count_temp			INT(10);                #存放临时表中记录数量	
	
	DECLARE done INT DEFAULT FALSE;                                 -- 创建游标结束标志变量		
	DECLARE mycur CURSOR FOR                                                       -- 创建游标
	SELECT S.V1,
	       S.ALARMTYPEID,
	       (SELECT T.ALARMTYPENAME
                   FROM ALARMTYPE T
                   WHERE T.ID = S.ALARMTYPEID) ALARMNAME
               FROM RAIN_ALARMPARA S
               WHERE S.DEVICEID = CUR_DEVICEID
               AND S.USE_FLAG = 1
               ORDER BY S.ALARMTYPEID ASC;        
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;				-- 指定游标循环结束时的返回值
        
        CREATE TEMPORARY TABLE IF NOT EXISTS t_rain_devicedata_hour_temp 			# 不存在则创建临时表
	     (
	      ID INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	      DEVICEID INT(10),
	      DACTIME DATETIME,
	      V1 DECIMAL(11, 4)
	     )ENGINE=memory DEFAULT CHARSET=utf8;
               
        SELECT AUTO_INCREMENT INTO CUR_ID FROM information_schema.`TABLES` WHERE TABLE_SCHEMA='highgain' AND TABLE_NAME='rain_devicedata_hour';
	SET CUR_DEVICEID = NEW.DeviceID;
	SET CUR_VAL      = NEW.V1;
	
	SELECT t.PROJECTID, t.MONITORDEVICECODE, t.DEVICENAME                                 #从测点信息表中读取测点信息
	    INTO PROJECTID, MONITORDEVICECODE, DEVICENAME
        FROM RAIN_DEVICE t
            WHERE t.USE_FLAG = 1 AND t.ID = CUR_DEVICEID;
        
        DELETE FROM t_rain_devicedata_hour_temp;                                             -- 使用前先清空临时表 
        INSERT INTO t_rain_devicedata_hour_temp(                                             #向临时表中插入数据
		 SELECT m.id,
			m.deviceId,
			m.dactime,
			m.v1			
		 FROM (SELECT t.id,t.deviceId,t.dactime,t.v1
		       FROM Rain_Devicedata_Hour t
		       WHERE t.ID < CUR_ID
		       AND t.DeviceID = CUR_DEVICEID
		       ORDER BY t.id DESC LIMIT 2)m);		       
        SELECT COUNT(*) INTO count_temp FROM t_rain_devicedata_hour_temp ;
        
	IF (count_temp = 2) THEN
	    SELECT v1 INTO HIS_FIRST_VAL FROM t_rain_devicedata_hour_temp LIMIT 0,1;
	    SELECT v1 INTO HIS_SECOND_VAL FROM t_rain_devicedata_hour_temp LIMIT 1,1;	    
	    -- 打开游标
	    OPEN mycur;
	    -- 遍历游标里的数据
            read_loop:LOOP
	    -- 将游标当前指向的数据，赋给当前定义的变量中
	    FETCH mycur INTO ALARM_VAL, ALARMTYPEID, ALARMTYPENAME;
	    -- 判断游标的循环是否结束
	    IF done THEN 
		LEAVE read_loop;			-- 跳出游标循环
	    END IF;
	    IF (ALARM_VAL <> 0 AND ABS(CUR_VAL) >= ALARM_VAL AND ABS(HIS_FIRST_VAL)>= ALARM_VAL AND ABS(HIS_SECOND_VAL)>= ALARM_VAL) THEN		
	      SET ALARM_MESSAGE = CONCAT('降雨量',ALARMTYPENAME,',数值:',CUR_VAL,'mm/h');
	      INSERT INTO ALARMLOG
		(PROJECTID,
		 ALARMTYPEID,
		 MONITORDEVICECODE,
		 MESSAGE,
		 CREATE_TIME,
		 DEVICEID,
		 DEVICENAME)
	      VALUES
		(PROJECTID,
		 ALARMTYPEID,
		 MONITORDEVICECODE,
		 ALARM_MESSAGE,
		 NOW(),
		 CUR_DEVICEID,
		 DEVICENAME);
		 LEAVE read_loop;			-- 跳出游标循环	      
	    END IF;
	    
	    
	    -- 结束游标循环
	    END LOOP;
	    -- 关闭游标
	    CLOSE mycur;
	    
	
	END IF;
    END;

