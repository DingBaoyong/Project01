create definer = root@localhost event E_FLOWDATA_ONEHOUR
  on schedule
    every '1' HOUR
      starts '2017-10-07 17:37:39'
  enable
do
  BEGIN
	    CALL P_FLOWDATA_ONEHOUR();
	END;

