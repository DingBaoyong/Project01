create procedure P_TURBIDATA_ONEHOUR()
  BEGIN
	DECLARE time1 DATETIME;
	SET time1 = DATE_ADD(NOW(), INTERVAL -1 HOUR);
	INSERT INTO turbi_devicedata_onehour
	    (deviceid, v1, v2, v3, v4, v5, dactime)
	    (SELECT deviceid,
		    AVG(v1),
		    AVG(v2),
		    AVG(v3),
		    AVG(v4),
		    AVG(v5),
		    DATE_FORMAT(NOW(),'%Y/%m/%d %H')
	       FROM turbi_devicedata
	      WHERE DATE_FORMAT(dactime,'%Y/%m/%d %H') = DATE_FORMAT(time1,'%Y/%m/%d %H')
	      GROUP BY deviceid);
    END;

