create procedure P_BEACHDATA_ONEHOUR()
  BEGIN
	declare time1 DATETIME;
	set time1 = date_add(now(), interval -1 hour);
	insert into beach_devicedata_onehour
	    (deviceid, v1, v2, v3, v4, v5, dactime)
	    (select deviceid,
		    avg(v1),
		    avg(v2),
		    avg(v3),
		    avg(v4),
		    avg(v5),
		    DATE_FORMAT(NOW(),'%Y/%m/%d %H')
	       from beach_devicedata
	      where DATE_FORMAT(dactime,'%Y/%m/%d %H') = DATE_FORMAT(time1,'%Y/%m/%d %H')
	      group by deviceid);
END;

