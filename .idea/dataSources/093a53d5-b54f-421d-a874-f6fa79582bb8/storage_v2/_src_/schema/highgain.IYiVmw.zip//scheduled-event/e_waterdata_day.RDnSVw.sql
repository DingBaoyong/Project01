create definer = root@localhost event E_WATERDATA_DAY
  on schedule
    every '1' DAY
      starts '2017-10-07 18:10:55'
  enable
do
  BEGIN
	    CALL P_WATERDATA_DAY();
	END;

