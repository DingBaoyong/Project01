create procedure P_LEVELDATA_THREEHOUR()
  BEGIN
	declare time1 DATETIME;
	declare time2 DATETIME;
	set time1 = DATE_ADD(NOW(),INTERVAL -3 HOUR);
	set time2 = DATE_ADD(NOW(),INTERVAL -1 HOUR);

	insert into level_devicedata_threehour (deviceid,v1,v2,v3,v4,v5,dactime)
	(
		select m.deviceid,m.v1,m.v2,m.v3,m.v4,m.v5,DATE_FORMAT(NOW(),'%Y/%m/%d %H') from
		(
			select t.deviceid,t.v1,t.v2,t.v3,t.v4,t.v5 from level_devicedata t where t.id in
			(
				select max(id) from level_devicedata 
				where DATE_FORMAT(dactime,'%Y/%m/%d %H') between DATE_FORMAT(time1,'%Y/%m/%d %H') and DATE_FORMAT(time2,'%Y/%m/%d %H')
				group by deviceid
			)
		)m
	);

END;

