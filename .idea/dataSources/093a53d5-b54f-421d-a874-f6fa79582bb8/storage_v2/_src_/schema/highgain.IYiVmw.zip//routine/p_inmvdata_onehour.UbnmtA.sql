create procedure P_INMVDATA_ONEHOUR()
  BEGIN
	declare time1 DATETIME;
	-- 创建接收游标数据的变量
	declare cur_deviceid int;
	declare cur_dactime DATETIME;
	declare cur_dx decimal(13,4);		-- 当前要插入的位移值
	declare cur_dy decimal(13,4);
	declare cur_dh decimal(13,4);
	declare cur_dxy decimal(13,4);
	declare cur_dxyh decimal(13,4);
	declare cur_vx decimal(13,4);		-- 当前要插入的速度值
	declare cur_vy decimal(13,4);
	declare cur_vh decimal(13,4);
	declare cur_vxy decimal(13,4);
	declare cur_vxyh decimal(13,4);
	declare cur_ax decimal(13,4);		-- 当前要插入的加速度值
	declare cur_ay decimal(13,4);
	declare cur_ah decimal(13,4);
	declare cur_axy decimal(13,4);
	declare cur_axyh decimal(13,4);
	-- 创建游标结束标志变量
	declare done int default false;
	
	-- 创建游标
	declare mycur cursor for 
	select deviceid,avg(dx),avg(dy),avg(dh),avg(dxy),avg(dxyh),
					avg(vx),avg(vy),avg(vh),avg(vxy),avg(vxyh),avg(ax),avg(ay),avg(ah),avg(axy),avg(axyh),DATE_FORMAT(NOW(),'%Y/%m/%d %H')
	from inmv_devicedata
	where DATE_FORMAT(dactime,'%Y/%m/%d %H') = DATE_FORMAT(time1,'%Y/%m/%d %H') group by deviceid;
					
	-- 指定游标循环结束时的返回值
	declare continue HANDLER for not found set done = true;
	-- 设置当前查询游标时间
	set time1 = DATE_ADD(NOW(),INTERVAL -1 HOUR);
	
	-- 打开游标
	open mycur;
	
	-- 遍历游标里的数据
	read_loop:loop
	-- 将游标当前指向的数据，赋给当前定义的变量中
	fetch mycur into 
	cur_deviceid,cur_dx,cur_dy,cur_dh,cur_dxy,cur_dxyh,cur_vx,cur_vy,cur_vh,cur_vxy,cur_vxyh,
	cur_ax,cur_ay,cur_ah,cur_axy,cur_axyh,cur_dactime;
	-- 判断游标的循环是否结束
	if done then 
			leave read_loop;			-- 跳出游标循环
	end if;
	
	-- 将数据插入inmv_devicedata_onehour中
	insert into inmv_devicedata_onehour (deviceid,dx,dy,dh,dxy,dxyh,vx,vy,vh,vxy,vxyh,ax,ay,ah,axy,axyh,dactime)
	values (cur_deviceid,cur_dx,cur_dy,cur_dh,cur_dxy,cur_dxyh,cur_vx,cur_vy,cur_vh,cur_vxy,cur_vxyh,
	cur_ax,cur_ay,cur_ah,cur_axy,cur_axyh,cur_dactime);
	
	-- 结束游标循环
	end loop;
	-- 关闭游标
	close mycur;
	
END;

