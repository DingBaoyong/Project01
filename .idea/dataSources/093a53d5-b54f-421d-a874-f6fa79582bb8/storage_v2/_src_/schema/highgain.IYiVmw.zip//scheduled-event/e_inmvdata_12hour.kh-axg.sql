create definer = root@localhost event E_INMVDATA_12HOUR
  on schedule
    every '12' HOUR
      starts '2017-10-07 17:46:54'
  enable
do
  BEGIN
	    CALL P_INMVDATA_12HOUR();
	END;

