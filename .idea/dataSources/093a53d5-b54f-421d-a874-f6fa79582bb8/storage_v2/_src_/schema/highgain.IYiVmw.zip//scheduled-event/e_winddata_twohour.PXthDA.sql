create definer = root@localhost event E_WINDDATA_TWOHOUR
  on schedule
    every '2' HOUR
      starts '2017-10-07 18:14:33'
  enable
do
  BEGIN
	    CALL P_WINDDATA_TWOHOUR();
	END;

