create definer = root@localhost event E_FLOWDATA_THREEHOUR
  on schedule
    every '3' HOUR
      starts '2017-10-07 17:40:52'
  enable
do
  BEGIN
	    CALL P_FLOWDATA_THREEHOUR();
	END;

