create definer = root@localhost event E_INMVDATA_THREEHOUR
  on schedule
    every '3' HOUR
      starts '2017-10-07 17:45:52'
  enable
do
  BEGIN
	    CALL P_INMVDATA_THREEHOUR();
	END;

