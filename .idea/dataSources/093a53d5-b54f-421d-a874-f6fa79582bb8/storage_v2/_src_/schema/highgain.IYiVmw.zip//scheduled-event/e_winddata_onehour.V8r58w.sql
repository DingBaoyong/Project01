create definer = root@localhost event E_WINDDATA_ONEHOUR
  on schedule
    every '1' HOUR
      starts '2017-10-07 18:13:28'
  enable
do
  BEGIN
	    CALL P_WINDDATA_ONEHOUR();
	END;

