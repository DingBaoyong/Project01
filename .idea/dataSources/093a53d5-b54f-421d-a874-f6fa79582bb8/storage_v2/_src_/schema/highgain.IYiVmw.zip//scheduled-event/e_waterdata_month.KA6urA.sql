create definer = root@localhost event E_WATERDATA_MONTH
  on schedule
    every '1' MONTH
      starts '2017-10-07 18:11:33'
  enable
do
  BEGIN
	    CALL P_WATERDATA_MONTH();
	END;

