create definer = root@localhost event E_TURBIDATA_TWOHOUR
  on schedule
    every '2' HOUR
      starts '2017-10-07 17:27:32'
  enable
do
  BEGIN
	    CALL P_TURBIDATA_TWOHOUR();
	END;

