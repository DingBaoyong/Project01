create procedure P_INMVDATA_MONTH()
  BEGIN
	declare time1 DATETIME;
	declare time2 DATETIME;
	
	set time1 = DATE_ADD(NOW(),INTERVAL -1 MONTH);
	set time2 = DATE_ADD(NOW(),INTERVAL -1 HOUR);
	
	insert into inmv_devicedata_month
	(deviceid,dx,dy,dh,dxy,dxyh,vx,vy,vh,vxy,vxyh,ax,ay,ah,axy,axyh,dactime) 
	(
		select m.deviceid,m.dx,m.dy,m.dh,m.dxy,m.dxyh,m.vx,m.vy,m.vh,m.vxy,m.vxyh,m.ax,m.ay,m.ah,m.axy,m.axyh,DATE_FORMAT(NOW(),'%Y/%m/%d %H') from
		(
			select t.deviceid,t.dx,t.dy,t.dh,t.dxy,t.dxyh,t.vx,t.vy,t.vh,t.vxy,t.vxyh,t.ax,t.ay,t.ah,t.axy,t.axyh
			from inmv_devicedata t where t.dataid in
			(
				select max(dataid) from inmv_devicedata where DATE_FORMAT(dactime,'%Y/%m/%d %H') between DATE_FORMAT(time1,'%Y/%m/%d %H') and DATE_FORMAT(time2,'%Y/%m/%d %H')
				group by deviceid
			)
		)m
	);
END;

