create definer = root@localhost event E_BEACHDATA_MONTH
  on schedule
    every '1' MONTH
      starts '2017-10-07 17:31:08'
  enable
do
  BEGIN
	    CALL P_BEACHDATA_MONTH();
	END;

