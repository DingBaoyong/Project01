create definer = root@localhost event E_INMVDATA_TWOHOUR
  on schedule
    every '2' HOUR
      starts '2017-10-07 17:45:18'
  enable
do
  BEGIN
	    CALL P_INMVDATA_TWOHOUR();
	END;

