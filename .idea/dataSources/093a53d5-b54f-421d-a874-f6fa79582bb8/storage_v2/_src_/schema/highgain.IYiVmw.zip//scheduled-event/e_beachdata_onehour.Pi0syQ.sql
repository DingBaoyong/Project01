create definer = root@localhost event E_BEACHDATA_ONEHOUR
  on schedule
    every '1' HOUR
      starts '2017-10-07 17:24:15'
  enable
do
  BEGIN
	    CALL P_BEACHDATA_ONEHOUR();
	END;

