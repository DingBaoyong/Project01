create definer = root@localhost event E_LEVELDATA_DAY
  on schedule
    every '1' DAY
      starts '2017-10-07 17:51:23'
  enable
do
  BEGIN
	    CALL P_LEVELDATA_DAY();
	END;

