create definer = root@localhost event E_SURFDATA_ONEHOUR
  on schedule
    every '1' HOUR
      starts '2017-10-07 18:00:02'
  enable
do
  BEGIN
	    CALL P_SURFDATA_ONEHOUR();
	END;

