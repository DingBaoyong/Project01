create definer = root@localhost event E_INMVDATA_ONEHOUR
  on schedule
    every '1' HOUR
      starts '2017-10-07 17:44:46'
  enable
do
  BEGIN
	   CALL P_INMVDATA_ONEHOUR();
	END;

