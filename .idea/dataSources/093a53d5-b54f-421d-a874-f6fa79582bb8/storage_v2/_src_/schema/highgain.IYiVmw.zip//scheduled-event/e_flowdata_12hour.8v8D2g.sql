create definer = root@localhost event E_FLOWDATA_12HOUR
  on schedule
    every '12' HOUR
      starts '2017-10-07 17:42:08'
  enable
do
  BEGIN
	    CALL P_FLOWDATA_12HOUR();
	END;

