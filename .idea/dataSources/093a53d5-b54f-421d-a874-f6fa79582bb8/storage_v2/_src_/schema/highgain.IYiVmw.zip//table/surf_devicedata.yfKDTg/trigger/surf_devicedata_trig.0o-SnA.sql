create trigger SURF_DEVICEDATA_TRIG
  before INSERT
  on surf_devicedata
  for each row
  BEGIN
	DECLARE CurX,CurY,CurH 			DECIMAL(11, 4);		#当前要插入的数据
	DECLARE CurDataId,CurDeviceID   	INT(10);
	DECLARE CurDacTime  			DATETIME;
	DECLARE t 				DECIMAL(12, 7);
	
	DECLARE OX,OY,OH,OXY,OXYH		DECIMAL(11, 4);	
	DECLARE T_VX,T_VY,T_VH,T_VXY,T_VXYH	DECIMAL(11, 4);	
	DECLARE T_AX,T_AY,T_AH,T_AXY,T_AXYH 	DECIMAL(11, 4);	
	
	DECLARE T_DX,T_DY,T_DH			DECIMAL(11, 4);		#临时变量，用于存储中间值
	
	DECLARE projectName,deviceName		VARCHAR(20);
	DECLARE projectId,monitorDeviceCode	INT(10);
	
	DECLARE count_temp			INT(10);                #存放临时表中记录数量
	DECLARE temp_X,temp_Y,temp_H		DECIMAL(11, 4);
	DECLARE temp_VX,temp_VY,temp_VH		DECIMAL(11, 4);
	DECLARE temp_DacTime			DATETIME;
	
	DECLARE count_data 			INT(10) DEFAULT 0;
	
	CREATE TEMPORARY TABLE IF NOT EXISTS t_temp 			# 不存在则创建临时表
	     (
	      DATAID INT(10) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
	      DEVICEID INT(10),
	      DACTIME DATETIME,
	      `X` DECIMAL(11, 4),
	      `Y` DECIMAL(11, 4),
	      `H` DECIMAL(11, 4),
	      VX DECIMAL(11, 4),
	      VY DECIMAL(11, 4),
	      VH DECIMAL(11, 4)
	     )ENGINE=memory DEFAULT CHARSET=utf8;
	 
	SELECT AUTO_INCREMENT INTO CurDataId FROM information_schema.`TABLES` WHERE TABLE_SCHEMA='highgain' AND TABLE_NAME='surf_devicedata';
	SET CurDeviceID = NEW.DeviceID;
	SET CurX        = NEW.X;
	SET CurY        = NEW.Y;
	SET CurH        = NEW.H;
	SET CurDacTime  = NEW.DACTIME;
	/*insert into test(DATAID,DEVICEID,`X`,`Y`,H,DACTIME)values(CurDataId,CurDeviceID,CurX,CurY,CurH,CurDacTime);*/
	
	 SELECT t.deviceName,
		t.monitordevicecode,
		s.projectid,
		p.projectname,
		t.v1,
		t.v2,
		t.v3
		INTO deviceName, monitordevicecode, projectId, projectName, ox, oy, oh
		FROM surf_device t, section s, project p
		WHERE t.id = CurDeviceID
		AND t.sectionid = s.sectionid
		AND s.projectid = p.projectid;
	 
	 DELETE FROM t_temp; -- 使用前先清空临时表。
		
	 INSERT INTO t_temp(
		 SELECT m.dataid,
			m.deviceId,
			m.dactime,
			m.x,
			m.y,
			m.h,
			m.vx,
			m.vy,
			m.vh
		 FROM (SELECT t.dataid,t.deviceId,t.dactime,t.x,t.y,t.h,t.vx,t.vy,t.vh
		       FROM SURF_DeviceData t
		       WHERE t.DataID < CurDataId
		       AND t.DeviceID = CurDeviceID
		       ORDER BY t.dataid DESC LIMIT 2)m);
		       
	SELECT COUNT(*) INTO count_temp FROM t_temp ;
	
	IF (count_temp >= 1) THEN
	    SELECT `x`,`y`,h,vx,vy,vh,dactime INTO temp_X,temp_Y,temp_H,temp_VX,temp_VY,temp_VH,temp_DacTime FROM t_temp ORDER BY dataid DESC LIMIT 1;
	    SET ox   = CurX - ox;
	    SET oY   = CurY - OY;
	    SET oH   = CurH - oH;
	    SET OXY  = SQRT(POWER(OX, 2) + POWER(OY, 2));
	    SET OXYH = SQRT(POWER(OX, 2) + POWER(OY, 2) + POWER(OH, 2));
	    SET T_DX = CurX - temp_X;
	    SET T_DY = CurY - temp_Y;
	    SET T_DH = CurH - temp_H;
	    -- T_DXY  := sqrt(power(T_DX, 2) + power(T_DY, 2));
	    -- T_DXYH := sqrt(power(T_DX, 2) + power(T_DY, 2) + power(T_DH, 2));
	    -- t := ROUND(TO_NUMBER(CurDacTime - l_tes(1).dactime) * 24); --hours
	    SET t = (UNIX_TIMESTAMP(CurDacTime) - UNIX_TIMESTAMP(temp_DacTime))/3600; -- hours  不可能为整数
	    -- t := ROUND(TO_NUMBER(CurDacTime-l_tes(1).dactime)*24 *60 *60); --seconds
	    SET T_VX = T_DX / t; -- unit: m/hour
	    SET T_VY = T_DY / t;
	    SET T_VH = T_DH / t;
	    SET T_VXY = SQRT(POWER(T_VX, 2) + POWER(T_VY, 2));
	    SET T_VXYH = SQRT(POWER(T_VX, 2) + POWER(T_VY, 2) + POWER(T_VH, 2));
	    IF (count_temp = 2) THEN
	      -- t1 := ROUND(TO_NUMBER(l_tes(1).dactime-l_tes(2).dactime)*24*60*60);--秒
	      -- t2 := ROUND(TO_NUMBER(CurDacTime-l_tes(1).dactime)*24*60*60);
	      --       t1 := ROUND(TO_NUMBER(l_tes(1).dactime-l_tes(2).dactime)*24);--小时
	      --         t2 := ROUND(TO_NUMBER(CurDacTime-l_tes(1).dactime)*24);
	      --        T_AX := (T_DX/t2 - (l_tes(2).X - l_tes(1).X)/t1)/t2;
	      --        T_AY := (T_DY/t2 - (l_tes(1).Y - l_tes(2).Y)/t1)/t2;
	      --         T_AH := (T_DH/t2 - (l_tes(1).H - l_tes(2).H)/t1)/t2;
	      --       T_AXY := sqrt(power(T_AX,2) + power(T_AY,2));
	      --      T_AXYH := sqrt(power(T_AX,2) + power(T_AY,2) + power(T_AH,2));
	      SET T_AX 	 = (T_VX - temp_VX) / t;
	      SET T_AY   = (T_VY - temp_VY) / t;
	      SET T_AH   = (T_VH - temp_VH) / t;
	      SET T_AXY  = SQRT(POWER(T_AX, 2) + POWER(T_AY, 2));
	      SET T_AXYH = SQRT(POWER(T_AX, 2) + POWER(T_AY, 2) + POWER(T_AH, 2));
	    ELSE
	      SET T_AX   = 0;
	      SET T_AY   = 0;
	      SET T_AH   = 0;
	      SET T_AXY  = 0;
	      SET T_AXYH = 0;
	    END IF;    
	  ELSE
	    SET OX     = 0;
	    SET OY     = 0;
	    SET OH     = 0;
	    SET T_AX   = 0;
	    SET T_AY   = 0;
	    SET T_AH   = 0;
	    SET OXY    = 0;
            SET OXYH   = 0;
	    SET T_AXY  = 0;
	    SET T_AXYH = 0;
	    SET T_VX   = 0;
	    SET T_VY   = 0;
	    SET T_VH   = 0;
	    SET T_VXY  = 0;
	    SET T_VXYH = 0;
	  END IF;
	  
	  SET NEW.DX   = OX;
	  SET NEW.DY   = OY;
	  SET NEW.DH   = OH;
	  SET NEW.AX   = T_AX;
	  SET NEW.AY   = T_AY;
	  SET NEW.AH   = T_AH;
	  SET NEW.DXY  = OXY;
	  SET NEW.DXYH = OXYH;
	  SET NEW.AXY  = T_AXY;
	  SET NEW.AXYH = T_AXYH;
	  SET NEW.VX   = T_VX;
	  SET NEW.VY   = T_VY;
	  SET NEW.VH   = T_VH;
	  SET NEW.VXY  = T_VXY;
	  SET NEW.VXYH = T_VXYH;
	  
	  /*DELETE t FROM NEWDEVICEDATA t WHERE t.MONITORDEVICECODE = monitorDeviceCode AND t.DEVICEID = CurDeviceID;
	  INSERT INTO NEWDEVICEDATA
	      (projectid,
	       monitordevicecode,
	       dacetime,
	       deviceid,
	       devicename,
	       v1,
	       v2,
	       v3,
	       v4,
	       v5,
	       v6,
	       v7,
	       v8,
	       v9,
	       v10,
	       v11,
	       v12,
	       v13,
	       v14,
	       v15)
	    VALUES
	       (projectId,
		monitorDeviceCode,
		CurDacTime,
		CurDeviceID,
		deviceName,
		OX,
		OY,
		OH,
		OXY,
		OXYH,
		T_VX,
		T_VY,
		T_VH,
		T_VXY,
		T_VXYH,
		T_AX,
		T_AY,
		T_AH,
		T_AXY,
		T_AXYH);*/
	  
	  /*if (monitordevicecode=1) then
	     select count(*) into count_data from NEWDEVICEDATA where monitordevicecode=1 and deviceid=CurDeviceID;
	  end if;
	  if (monitordevicecode=5) then
	     select count(*) into count_data from NEWDEVICEDATA where monitordevicecode=5 and deviceid=CurDeviceID;
	  end if;
	  if (monitordevicecode=6) then
	     select count(*) into count_data from NEWDEVICEDATA where monitordevicecode=6 and deviceid=CurDeviceID;
	  end if;
	  
	  if (count_data = 0) then
	    insert into NEWDEVICEDATA
	      (projectid,
	       monitordevicecode,
	       dacetime,
	       deviceid,
	       devicename,
	       v1,
	       v2,
	       v3,
	       v4,
	       v5,
	       v6,
	       v7,
	       v8,
	       v9,
	       v10,
	       v11,
	       v12,
	       v13,
	       v14,
	       v15)
	    values
	       (projectId,
		monitordevicecode,
		CurDacTime,
		CurDeviceID,
		deviceName,
		OX,
		OY,
		OH,
		OXY,
		OXYH,
		T_VX,
		T_VY,
		T_VH,
		T_VXY,
		T_VXYH,
		T_AX,
		T_AY,
		T_AH,
		T_AXY,
		T_AXYH);
	  else
	    update NEWDEVICEDATA t set t.dacetime=CurDacTime,t.devicename=deviceName,t.v1=OX,t.v2=OY,t.v3=OH,t.v4=OXY,t.v5=OXYH,t.v6=T_VX,t.v7=T_VY,t.v8=T_VH,t.v9=T_VXY,t.v10=T_VXYH,t.v11=T_AX,t.v12=T_AY,t.v13=T_AH,t.v14=T_AXY,t.v15=T_AXYH
	    where t.monitordevicecode=monitorDeviceCode and t.deviceid=CurDeviceID;
	       
	  end if;*/
	
    END;

