create definer = root@localhost event E_WINDDATA_THREEHOUR
  on schedule
    every '3' HOUR
      starts '2017-10-07 18:15:16'
  enable
do
  BEGIN
	    CALL P_WINDDATA_THREEHOUR();
	END;

