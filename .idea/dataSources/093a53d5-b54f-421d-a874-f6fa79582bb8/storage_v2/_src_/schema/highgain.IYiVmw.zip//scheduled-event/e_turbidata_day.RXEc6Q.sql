create definer = root@localhost event E_TURBIDATA_DAY
  on schedule
    every '1' DAY
      starts '2017-10-07 17:30:27'
  enable
do
  BEGIN
	    CALL P_TURBIDATA_DAY();
	END;

