create definer = root@localhost event E_LEVELDATA_THREEHOUR
  on schedule
    every '3' HOUR
      starts '2017-10-07 17:50:18'
  enable
do
  BEGIN
	    CALL P_LEVELDATA_THREEHOUR();
	END;

