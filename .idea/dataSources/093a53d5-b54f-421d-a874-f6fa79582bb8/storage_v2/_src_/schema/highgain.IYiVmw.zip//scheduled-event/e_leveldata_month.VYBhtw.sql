create definer = root@localhost event E_LEVELDATA_MONTH
  on schedule
    every '1' MONTH
      starts '2017-10-07 17:51:55'
  enable
do
  BEGIN
	    CALL P_LEVELDATA_MONTH();
	END;

