create definer = root@localhost event E_INMVDATA_MONTH
  on schedule
    every '1' MONTH
      starts '2017-10-07 17:48:01'
  enable
do
  BEGIN
	    CALL P_INMVDATA_MONTH();
	END;

