create definer = root@localhost event E_SURFDATA_MONTH
  on schedule
    every '1' MONTH
      starts '2017-10-07 18:03:31'
  enable
do
  BEGIN
	    CALL P_SURFDATA_MONTH();
	END;

