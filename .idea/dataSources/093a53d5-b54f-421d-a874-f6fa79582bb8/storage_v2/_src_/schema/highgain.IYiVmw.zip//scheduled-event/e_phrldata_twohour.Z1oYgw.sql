create definer = root@localhost event E_PHRLDATA_TWOHOUR
  on schedule
    every '2' HOUR
      starts '2017-10-07 17:55:29'
  enable
do
  BEGIN
	    CALL P_PHRLDATA_TWOHOUR();
	END;

