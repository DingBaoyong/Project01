create procedure P_TURBIDATA_TWOHOUR()
  BEGIN
	DECLARE time1 DATETIME;
	DECLARE time2 DATETIME;
	SET time1 = DATE_ADD(NOW(), INTERVAL -2 HOUR);
	SET time2 = DATE_ADD(NOW(), INTERVAL -1 HOUR);
	INSERT INTO turbi_devicedata_twohour
	(deviceid, v1, v2, v3, v4, v5, dactime)
	(SELECT m.deviceid, m.v1, m.v2, m.v3, m.v4, m.v5,DATE_FORMAT(NOW(),'%Y/%m/%d %H')
		FROM (SELECT t.deviceid, t.v1, t.v2, t.v3, t.v4, t.v5 FROM beach_devicedata t WHERE t.id IN 
		(SELECT MAX(id) FROM turbi_devicedata WHERE DATE_FORMAT(dactime,'%Y/%m/%d %H') BETWEEN DATE_FORMAT(time1,'%Y/%m/%d %H') AND DATE_FORMAT(time2,'%Y/%m/%d %H') GROUP BY deviceid))m);
    END;

