create definer = root@localhost event E_WATERDATA_TWOHOUR
  on schedule
    every '2' HOUR
      starts '2017-10-07 18:08:21'
  enable
do
  BEGIN
	    CALL P_WATERDATA_TWOHOUR();
	END;

