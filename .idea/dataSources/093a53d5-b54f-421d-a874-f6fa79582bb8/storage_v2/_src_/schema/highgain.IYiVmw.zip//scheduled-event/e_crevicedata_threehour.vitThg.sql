create definer = root@localhost event E_CREVICEDATA_THREEHOUR
  on schedule
    every '3' HOUR
      starts '2017-10-07 17:11:15'
  enable
do
  BEGIN
	    CALL P_CREVICEDATA_THREEHOUR();
	END;

