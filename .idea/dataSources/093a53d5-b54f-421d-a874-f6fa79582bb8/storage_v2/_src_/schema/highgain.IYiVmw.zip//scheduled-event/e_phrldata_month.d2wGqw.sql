create definer = root@localhost event E_PHRLDATA_MONTH
  on schedule
    every '1' MONTH
      starts '2017-10-07 17:59:08'
  enable
do
  BEGIN
	    CALL P_PHRLDATA_MONTH();
	END;

