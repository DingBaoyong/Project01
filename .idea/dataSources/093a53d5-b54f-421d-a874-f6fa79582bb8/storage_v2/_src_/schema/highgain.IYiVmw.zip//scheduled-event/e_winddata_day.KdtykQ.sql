create definer = root@localhost event E_WINDDATA_DAY
  on schedule
    every '1' DAY
      starts '2017-10-07 18:16:59'
  enable
do
  BEGIN
	    CALL P_WINDDATA_DAY();
	END;

