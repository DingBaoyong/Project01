create definer = root@localhost event E_SURFDATA_DAY
  on schedule
    every '1' DAY
      starts '2017-10-07 18:02:55'
  enable
do
  BEGIN
	    CALL P_SURFDATA_DAY();
	END;

