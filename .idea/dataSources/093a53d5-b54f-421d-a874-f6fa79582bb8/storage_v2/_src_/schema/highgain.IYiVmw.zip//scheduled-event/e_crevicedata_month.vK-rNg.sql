create definer = root@localhost event E_CREVICEDATA_MONTH
  on schedule
    every '1' MONTH
      starts '2017-10-07 17:19:32'
  enable
do
  BEGIN
	    CALL P_CREVICEDATA_MONTH();
	END;

