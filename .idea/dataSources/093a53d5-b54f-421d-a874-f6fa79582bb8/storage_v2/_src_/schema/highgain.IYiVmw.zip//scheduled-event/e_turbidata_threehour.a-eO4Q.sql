create definer = root@localhost event E_TURBIDATA_THREEHOUR
  on schedule
    every '3' HOUR
      starts '2017-10-07 17:28:12'
  enable
do
  BEGIN
	    CALL P_TURBIDATA_THREEHOUR();
	END;

