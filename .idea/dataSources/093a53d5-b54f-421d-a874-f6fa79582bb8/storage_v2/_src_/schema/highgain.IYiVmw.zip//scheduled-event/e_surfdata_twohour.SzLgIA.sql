create definer = root@localhost event E_SURFDATA_TWOHOUR
  on schedule
    every '2' HOUR
      starts '2017-10-07 18:00:33'
  enable
do
  BEGIN
	    CALL P_SURFDATA_TWOHOUR();
	END;

