create procedure P_WATERDATA_ONEHOUR()
  BEGIN
	DECLARE time1 DATETIME;
	SET time1 = DATE_ADD(NOW(),INTERVAL -1 HOUR);
	insert into water_devicedata_onehour(deviceid, v1, v2, v3, v4, v5, dactime)
  (select deviceid,avg(v1),avg(v2),avg(v3),avg(v4),avg(v5),DATE_FORMAT(NOW(),'%Y/%m/%d %H')
		from water_devicedata
    where DATE_FORMAT(dactime,'%Y/%m/%d %H') = DATE_FORMAT(time1,'%Y/%m/%d %H')
		group by deviceid
  );
END;

