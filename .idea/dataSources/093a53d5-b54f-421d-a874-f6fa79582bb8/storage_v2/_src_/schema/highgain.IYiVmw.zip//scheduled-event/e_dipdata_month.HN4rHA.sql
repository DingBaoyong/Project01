create definer = root@localhost event E_DIPDATA_MONTH
  on schedule
    every '1' MONTH
      starts '2017-10-07 17:36:49'
  enable
do
  BEGIN
	    CALL P_DIPDATA_MONTH();
	END;

