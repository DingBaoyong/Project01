create definer = root@localhost event E_WINDDATA_MONTH
  on schedule
    every '1' MONTH
      starts '2017-10-07 18:17:47'
  enable
do
  BEGIN
	    CALL P_WINDDATA_MONTH();
	END;

