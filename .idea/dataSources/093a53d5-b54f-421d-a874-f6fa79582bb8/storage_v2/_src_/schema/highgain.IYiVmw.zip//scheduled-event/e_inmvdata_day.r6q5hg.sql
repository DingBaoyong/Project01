create definer = root@localhost event E_INMVDATA_DAY
  on schedule
    every '1' DAY
      starts '2017-10-07 17:47:23'
  enable
do
  BEGIN
	    CALL P_INMVDATA_DAY();
	END;

